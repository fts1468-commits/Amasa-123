import React, { useState, useMemo } from 'react';
import {
  RotateCcw,
  Plus,
  Search,
  Users,
  Eye,
  MessageCircle,
  Paperclip,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Check,
  DollarSign,
  Calendar,
  X,
  Play,
  ArrowRight,
  TrendingUp,
  Clock,
  Send,
  AlertTriangle,
  Phone,
  Building2,
  Coffee,
  Sparkles,
  UploadCloud,
  FileText,
  Wallet,
  Camera,
  Image,
  Trash2,
  Percent,
  ShieldAlert,
  ChevronDown,
  Home,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Booking } from '../../types';

interface GuardActionModalData {
  kind: 'arrive' | 'insrecv' | 'exit' | 'insret';
  booking: Booking;
}

export const DashboardTab: React.FC = () => {
  const {
    properties,
    bookings,
    filteredBookings,
    todayArrivals,
    todayDepartures,
    sendCheckoutReminder,
    markCheckedOut,
    returnInsuranceDeposit,
    guardMarkArrived,
    guardReceiveInsurance,
    guardRequestInsuranceReturn,
    setBookingModalOpen,
    setSelectedPropertyId,
    setActiveTab,
    updateBookingStatus,
    isAdmin,
    isGuard,
    currentMarketerId,
    completeBookingPayment,
    sendPaymentCompletionRequest,
    guard,
    recordCustomerArrival,
    recordInsuranceReceived,
    notifyGuardForCashPayment,
    guardProcessDeparture,
    toggleAdminCommissionApproval,
  } = useApp();

  const [guardConfirm, setGuardConfirm] = useState<GuardActionModalData | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedBookingForDetails, setSelectedBookingForDetails] = useState<Booking | null>(null);
  const [detailsTitle, setDetailsTitle] = useState('تفاصيل الحجز');

  // Complete payment modal state
  const [paymentModalBooking, setPaymentModalBooking] = useState<Booking | null>(null);
  const [paymentReceiptFile, setPaymentReceiptFile] = useState<{ name: string; dataUrl?: string } | null>(null);
  const [paymentFileError, setPaymentFileError] = useState<string | null>(null);

  // New Arrival Modal State (دخول اليوم - عند وصول العميل تفتح نافذة بها خيارين: دفع إيصال مع إرفاق، ودفع كاش + إشعار للحارس والإدارة)
  const [arrivalModalBooking, setArrivalModalBooking] = useState<Booking | null>(null);
  const [arrivalPayMethod, setArrivalPayMethod] = useState<'receipt' | 'cash'>('receipt');
  const [arrivalReceiptFile, setArrivalReceiptFile] = useState<{ name: string; dataUrl?: string } | null>(null);
  const [arrivalFileError, setArrivalFileError] = useState<string | null>(null);
  const [arrivalNotes, setArrivalNotes] = useState('');

  // Marketer Complete Payment Modal State (المسوقة تضغط زر إكمال الدفع ويظهر خيارين: رسالة ترحيب، وخيار طلب الدفع بإيصال أو كاش مع إشعار الحارس)
  const [marketerPaymentModalBooking, setMarketerPaymentModalBooking] = useState<Booking | null>(null);
  const [marketerPaymentTab, setMarketerPaymentTab] = useState<'welcome' | 'payment'>('payment');
  const [marketerPayMethod, setMarketerPayMethod] = useState<'receipt' | 'cash'>('receipt');
  const [marketerReceiptFile, setMarketerReceiptFile] = useState<{ name: string; dataUrl?: string } | null>(null);
  const [marketerFileError, setMarketerFileError] = useState<string | null>(null);
  const [marketerWelcomeCustomText, setMarketerWelcomeCustomText] = useState('');

  // New Insurance Modal State (دخول اليوم - عنصر التأمين تفتح نافذة بها خيارين: دفع إيصال مع إرفاق إلزامي، ودفع كاش + إشعار للحارس والإدارة)
  const [insuranceModalBooking, setInsuranceModalBooking] = useState<Booking | null>(null);
  const [insurancePayMethod, setInsurancePayMethod] = useState<'receipt' | 'cash'>('receipt');
  const [insuranceReceiptFile, setInsuranceReceiptFile] = useState<{ name: string; dataUrl?: string } | null>(null);
  const [insuranceFileError, setInsuranceFileError] = useState<string | null>(null);
  const [insuranceNotes, setInsuranceNotes] = useState('');

  // Insurance confirmation modal (old quick confirm)
  const [insuranceConfirmBooking, setInsuranceConfirmBooking] = useState<Booking | null>(null);

  // Receipt view modal
  const [viewReceiptBooking, setViewReceiptBooking] = useState<Booking | null>(null);

  // Guard Departure & Insurance Inspection Modal State (مغادرة اليوم: إعادة التأمين أو خصم مبلغ مع خانة إرفاق صور العبث والأضرار)
  const [guardInspectionBooking, setGuardInspectionBooking] = useState<Booking | null>(null);
  const [guardInspectionResult, setGuardInspectionResult] = useState<'full_refund' | 'deduction'>('full_refund');
  const [guardDeductionAmount, setGuardDeductionAmount] = useState<number>(0);
  const [guardDamageDesc, setGuardDamageDesc] = useState<string>('');
  const [guardDamagePhotos, setGuardDamagePhotos] = useState<{ name: string; dataUrl: string }[]>([]);
  const [guardInspectionError, setGuardInspectionError] = useState<string | null>(null);

  // Marketer Checkout Reminder Modal State (رسالة تذكير بالخروج تقوم المسوقة بذلك)
  const [reminderModalBooking, setReminderModalBooking] = useState<Booking | null>(null);
  const [customReminderMsg, setCustomReminderMsg] = useState<string>('');

  // Filter & search
  const [activeFilter, setActiveFilter] = useState<'all' | 'arrivals' | 'departures' | 'waitingDeposit'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAvailableProps, setShowAvailableProps] = useState(true);
  const [expandedBookingIds, setExpandedBookingIds] = useState<Record<string, boolean>>({});

  const toggleBookingExpanded = (id: string) => {
    setExpandedBookingIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);

  // Available today properties
  const availableTodayProperties = useMemo(() => {
    return properties.filter((prop) => {
      if (!prop.isPublished) return false;
      const isBooked = bookings.some(
        (b) =>
          b.propertyId === prop.id &&
          b.status !== 'cancelled' &&
          todayStr >= b.checkInDate &&
          todayStr < b.checkOutDate
      );
      return !isBooked;
    });
  }, [properties, bookings, todayStr]);

  const activeBookings = useMemo(() => {
    return filteredBookings.filter(
      (b) => b.status === 'confirmed' || b.status === 'pending_payment' || b.status === 'waiting_deposit'
    );
  }, [filteredBookings]);

  // Marketer sees today's arrivals for their bookings only, Admin & Guard see all
  const visibleArrivals = useMemo(() => {
    if (isAdmin || isGuard) return todayArrivals;
    return todayArrivals.filter((b) => b.marketerId === currentMarketerId);
  }, [todayArrivals, isAdmin, isGuard, currentMarketerId]);

  const matchesSearch = (b: Booking) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase().trim();
    return (
      b.customerName.toLowerCase().includes(term) ||
      b.customerPhone.includes(term) ||
      b.propertyName.toLowerCase().includes(term) ||
      (b.marketerName && b.marketerName.toLowerCase().includes(term))
    );
  };

  const searchFilteredArrivals = useMemo(() => visibleArrivals.filter(matchesSearch), [visibleArrivals, searchTerm]);
  const searchFilteredDepartures = useMemo(() => todayDepartures.filter(matchesSearch), [todayDepartures, searchTerm]);
  const searchFilteredActive = useMemo(() => activeBookings.filter(matchesSearch), [activeBookings, searchTerm]);
  const waitingDepositBookings = useMemo(
    () => bookings.filter((b) => b.status === 'waiting_deposit').filter(matchesSearch),
    [bookings, searchTerm]
  );
  const completedBookingsCount = useMemo(
    () => bookings.filter((b) => b.status === 'completed').length,
    [bookings]
  );

  const handleCheckoutReminder = (bookingId: string) => {
    const { whatsappUrl } = sendCheckoutReminder(bookingId);
    if (whatsappUrl) {
      window.open(whatsappUrl, '_blank');
    }
    showToast('تم فتح واتساب مع نص تذكير الخروج للعميل بنجاح');
  };

  const handlePaymentReminder = (bookingId: string) => {
    const { whatsappUrl } = sendPaymentCompletionRequest(bookingId);
    if (whatsappUrl) {
      window.open(whatsappUrl, '_blank');
    }
    showToast('تم فتح واتساب مع نص تذكير الدفع للعميل');
  };

  const openPaymentModal = (b: Booking) => {
    setPaymentModalBooking(b);
    setPaymentReceiptFile(null);
    setPaymentFileError(null);
  };

  const handleReceiptFileChange = (file?: File) => {
    setPaymentFileError(null);
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      setPaymentFileError('حجم الملف كبير، يرجى اختيار ملف أقل من 2 ميجابايت.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setPaymentReceiptFile({ name: file.name, dataUrl: String(reader.result) });
    };
    reader.readAsDataURL(file);
  };

  const submitPaymentCompletion = () => {
    if (!paymentModalBooking || !paymentReceiptFile) return;
    completeBookingPayment(paymentModalBooking.id, paymentReceiptFile.name, paymentReceiptFile.dataUrl);
    setPaymentModalBooking(null);
    setPaymentReceiptFile(null);
    showToast('تم حفظ الإيصال وتسجيل إكمال الدفع بنجاح');
  };

  const confirmInsuranceHandover = () => {
    if (insuranceConfirmBooking) {
      returnInsuranceDeposit(insuranceConfirmBooking.id);
      setInsuranceConfirmBooking(null);
      showToast('تم تسجيل تسليم التأمين للعميل بنجاح');
    }
  };

  const openArrivalModal = (bk: Booking) => {
    setArrivalModalBooking(bk);
    setArrivalPayMethod('receipt');
    setArrivalReceiptFile(null);
    setArrivalFileError(null);
    setArrivalNotes('');
  };

  const handleArrivalReceiptChange = (file?: File) => {
    setArrivalFileError(null);
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      setArrivalFileError('حجم الملف كبير، يرجى اختيار ملف أقل من 3 ميجابايت.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setArrivalReceiptFile({ name: file.name, dataUrl: String(reader.result) });
    };
    reader.readAsDataURL(file);
  };

  const submitArrivalConfirmation = () => {
    if (!arrivalModalBooking) return;
    if (arrivalPayMethod === 'receipt' && arrivalModalBooking.remainingAmount > 0 && !arrivalReceiptFile) {
      setArrivalFileError('يرجى إرفاق صورة إيصال السداد البنكي للمتابعة.');
      return;
    }
    recordCustomerArrival({
      bookingId: arrivalModalBooking.id,
      paymentMethod: arrivalPayMethod,
      receiptName: arrivalReceiptFile?.name,
      receiptDataUrl: arrivalReceiptFile?.dataUrl,
      notes: arrivalNotes,
    });
    const targetBooking = arrivalModalBooking;
    setArrivalModalBooking(null);
    showToast(`تم تأكيد وصول العميل (${targetBooking.customerName}) وإرسال إشعار فوري للحارس والإدارة بنجاح ✓`);
  };

  const handleGuardArrivalClick = (bk: Booking) => {
    guardMarkArrived(bk.id);
    showToast(`تم إشعار المسوقة (${bk.marketerName || 'المسؤولة'}) والإدارة بوصول العميل (${bk.customerName}) بنجاح ✓`);
  };

  const openMarketerPaymentModal = (bk: Booking, defaultTab: 'welcome' | 'payment' = 'payment') => {
    setMarketerPaymentModalBooking(bk);
    setMarketerPaymentTab(defaultTab);
    setMarketerPayMethod('receipt');
    setMarketerReceiptFile(null);
    setMarketerFileError(null);
    setMarketerWelcomeCustomText(
      `أهلاً وسهلاً بك أخي الكريم ${bk.customerName} في ${bk.propertyName} 🌿 يسعدنا ويشرفنا استقبالكم اليوم، ونتمنى لكم أوقاتاً ممتعة وسعيدة. لأي استفسار أو خدمة طوال إقامتكم نحن والحارس (${guard?.name || 'أبو راشد'}) بخدمتكم دائماً.`
    );
  };

  const handleMarketerReceiptChange = (file?: File) => {
    setMarketerFileError(null);
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      setMarketerFileError('حجم الملف كبير، يرجى اختيار ملف أقل من 3 ميجابايت.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setMarketerReceiptFile({ name: file.name, dataUrl: String(reader.result) });
    };
    reader.readAsDataURL(file);
  };

  const submitMarketerPayment = () => {
    if (!marketerPaymentModalBooking) return;
    const bk = marketerPaymentModalBooking;

    if (marketerPayMethod === 'receipt') {
      if (!marketerReceiptFile && bk.remainingAmount > 0) {
        setMarketerFileError('يرجى إرفاق صورة إيصال السداد البنكي للمتابعة.');
        return;
      }
      completeBookingPayment(bk.id, marketerReceiptFile?.name || 'إيصال سداد', marketerReceiptFile?.dataUrl);
      setMarketerPaymentModalBooking(null);
      showToast(`تم حفظ الإيصال وتأكيد إكمال الدفع للعميل (${bk.customerName}) بنجاح ✓`);
    } else {
      // تسليم المبلغ كاش: يرسل إشعار للحارس للذهاب لاستلام المبلغ وسعر المبلغ المتبقي
      notifyGuardForCashPayment({ bookingId: bk.id });
      setMarketerPaymentModalBooking(null);
      showToast(`تم إرسال إشعار عاجل للحارس (${guard?.name || 'أبو راشد'}) بالتوجه لاستلام المبلغ المتبقي (${bk.remainingAmount} ر.س) كاش ✓`);
    }
  };

  const sendWelcomeMessageWhatsApp = (bk: Booking, customMsg?: string) => {
    let clean = bk.customerPhone.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) clean = '966' + clean.substring(1);
    else if (!clean.startsWith('966')) clean = '966' + clean;

    const text =
      customMsg ||
      `أهلاً وسهلاً بك أخي الكريم ${bk.customerName} في ${bk.propertyName} 🌿 يسعدنا ويشرفنا استقبالكم اليوم، ونتمنى لكم أوقاتاً ممتعة وسعيدة. لأي استفسار أو خدمة طوال إقامتكم نحن والحارس (${guard?.name || 'أبو راشد'}) بخدمتكم دائماً.`;
    window.open(`https://wa.me/${clean}?text=${encodeURIComponent(text)}`, '_blank');
    showToast('تم فتح محادثة واتساب لإرسال رسالة الترحيب للعميل');
  };

  const openInsuranceModal = (bk: Booking) => {
    setInsuranceModalBooking(bk);
    setInsurancePayMethod('receipt');
    setInsuranceReceiptFile(null);
    setInsuranceFileError(null);
    setInsuranceNotes('');
  };

  const handleInsuranceReceiptChange = (file?: File) => {
    setInsuranceFileError(null);
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      setInsuranceFileError('حجم الملف كبير، يرجى اختيار ملف أقل من 3 ميجابايت.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setInsuranceReceiptFile({ name: file.name, dataUrl: String(reader.result) });
    };
    reader.readAsDataURL(file);
  };

  const submitInsuranceConfirmation = () => {
    if (!insuranceModalBooking) return;
    if (insurancePayMethod === 'receipt' && !insuranceReceiptFile) {
      setInsuranceFileError('يجب إرفاق ملف إيصال التأمين البنكي للمتابعة!');
      return;
    }
    recordInsuranceReceived({
      bookingId: insuranceModalBooking.id,
      paymentMethod: insurancePayMethod,
      receiptName: insuranceReceiptFile?.name,
      receiptDataUrl: insuranceReceiptFile?.dataUrl,
      notes: insuranceNotes,
    });
    const targetBooking = insuranceModalBooking;
    setInsuranceModalBooking(null);
    showToast(`تم تأكيد استلام التأمين (${targetBooking.insuranceAmount} ر.س) وإرسال إشعار فوري للحارس والإدارة بنجاح ✓`);
  };

  const getWhatsAppCustomerUrl = (phone: string, name: string, prop: string) => {
    let clean = phone.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) clean = '966' + clean.substring(1);
    else if (!clean.startsWith('966')) clean = '966' + clean;
    const text = `أهلاً بك أخي الكريم ${name}، يسعدنا استقبالكم اليوم في ${prop} الساعة 5 م. ونتمنى لكم إقامة ممتعة وسعيدة. لأي استفسار أو مساعدة نحن بخدمتكم دائماً.`;
    return `https://wa.me/${clean}?text=${encodeURIComponent(text)}`;
  };

  const getWhatsAppGuardUrl = (bk: Booking) => {
    let clean = (guard?.phone || '0598881234').replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) clean = '966' + clean.substring(1);
    else if (!clean.startsWith('966')) clean = '966' + clean;
    const text = `السلام عليكم يا أبو راشد (${guard?.name || 'حارس الاستراحة'})، بخصوص حجز اليوم في ${bk.propertyName} للعميل ${bk.customerName} (جوال: ${bk.customerPhone}). حبيت أتابع معك موعد وصول النزيل وتجهيز الاستراحة واستلام التأمين (${bk.insuranceAmount} ريال).`;
    return `https://wa.me/${clean}?text=${encodeURIComponent(text)}`;
  };

  const getWhatsAppAdminUrl = (bk: Booking) => {
    const text = `السلام عليكم إدارة ماسة (AMASA)، استفسار ومتابعة بخصوص حجز اليوم رقم ${bk.bookingNumber} في ${bk.propertyName} للعميل ${bk.customerName}. المتبقي للتحصيل: ${bk.remainingAmount} ر.س والتأمين: ${bk.insuranceAmount} ر.س.`;
    return `https://wa.me/966500000001?text=${encodeURIComponent(text)}`;
  };

  const openGuardInspectionModal = (bk: Booking) => {
    setGuardInspectionBooking(bk);
    setGuardInspectionResult('full_refund');
    setGuardDeductionAmount(0);
    setGuardDamageDesc('');
    setGuardDamagePhotos([]);
    setGuardInspectionError(null);
  };

  const handleDamagePhotoUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setGuardInspectionError(null);
    Array.from(files).forEach((file) => {
      if (file.size > 4 * 1024 * 1024) {
        setGuardInspectionError('تجاوزت بعض الصور الحد الأقصى المسموح (4 ميجابايت).');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          setGuardDamagePhotos((prev) => [...prev, { name: file.name, dataUrl: String(reader.result) }]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeDamagePhoto = (index: number) => {
    setGuardDamagePhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const submitGuardDepartureInspection = () => {
    if (!guardInspectionBooking) return;
    const bk = guardInspectionBooking;

    if (guardInspectionResult === 'deduction') {
      if (!guardDeductionAmount || guardDeductionAmount <= 0) {
        setGuardInspectionError('يرجى تحديد مبلغ الخصم بالريال السعودي.');
        return;
      }
      if (guardDeductionAmount > bk.insuranceAmount) {
        setGuardInspectionError(`مبلغ الخصم لا يمكن أن يتجاوز إجمالي مبلغ التأمين (${bk.insuranceAmount} ر.س).`);
        return;
      }
      if (!guardDamageDesc.trim()) {
        setGuardInspectionError('يرجى كتابة وصف موجز للعبث أو الأضرار المرصودة بالاستراحة.');
        return;
      }
    }

    guardProcessDeparture({
      bookingId: bk.id,
      result: guardInspectionResult,
      deductionAmount: guardInspectionResult === 'deduction' ? guardDeductionAmount : 0,
      damageDescription: guardInspectionResult === 'deduction' ? guardDamageDesc : undefined,
      damagePhotos: guardInspectionResult === 'deduction' ? guardDamagePhotos : undefined,
    });

    setGuardInspectionBooking(null);
    showToast(
      guardInspectionResult === 'full_refund'
        ? `تم تسجيل خروج النزيل تماماً وإشعار المسوقة والإدارة بسلامة الاستراحة وإعادة التأمين (${bk.insuranceAmount} ر.س) ✓`
        : `تم تسجيل خروج النزيل وتوثيق خصم (${guardDeductionAmount} ر.س) مع إرفاق الصور وإشعار المسوقة والإدارة فوراً ✓`
    );
  };

  const openMarketerReminderModal = (bk: Booking) => {
    const prop = properties.find((p) => p.id === bk.propertyId);
    const checkOutTime = prop?.checkOutTimeText || 'الساعة 2:00 ظهراً';
    const defaultText = `السلام عليكم ورحمة الله وبركاته، أخي الكريم ${bk.customerName} 🌿 نود تذكيركم بموعد تسجيل الخروج اليوم من (${bk.propertyName}) في تمام ${checkOutTime}، وتسليم المفتاح للحارس (${guard?.name || 'أبو راشد'}) لمعاينة الاستراحة واسترداد مبلغ التأمين (${bk.insuranceAmount} ر.س). شاكرين لكم وممتنين لاختياركم لنا.`;
    setReminderModalBooking(bk);
    setCustomReminderMsg(defaultText);
  };

  const sendMarketerReminder = (bk: Booking, customText?: string) => {
    const res = sendCheckoutReminder(bk.id);
    let url = res.whatsappUrl;
    if (customText) {
      const cleanPhone = (bk.customerPhone || '0550000000').replace(/\D/g, '').replace(/^0/, '966');
      url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(customText)}`;
    }
    window.open(url, '_blank');
    setReminderModalBooking(null);
    showToast(`تم إرسال تذكير الخروج للنزيل (${bk.customerName}) عبر واتساب المسوقة بنجاح ✓`);
  };

  const getWhatsAppDirectUrl = (phone: string, name: string, prop: string, type: 'arrival' | 'departure') => {
    let clean = phone.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) clean = '966' + clean.substring(1);
    else if (!clean.startsWith('966')) clean = '966' + clean;

    const text =
      type === 'arrival'
        ? `أهلاً بك أخي الكريم ${name}، يسعدنا استقبالكم اليوم في ${prop} الساعة 5 م. ونتمنى لكم إقامة ممتعة وسعيدة. لأي استفسار نحن بخدمتكم دائماً.`
        : `أهلاً بك أخي الكريم ${name}، نأمل أن تكونوا قضيتم أوقاتاً ممتعة في ${prop}. نود تذكيركم بموعد المغادرة الساعة 2 م، وسيتم تسليم مبلغ التأمين عند الخروج. شكراً لكم.`;

    return `https://wa.me/${clean}?text=${encodeURIComponent(text)}`;
  };

  return (
    <div className="pb-28 max-w-5xl mx-auto px-3 sm:px-4 pt-3 space-y-4">
      {/* Guard Confirmation Modal - تنبيه تأكيد الإرسال لتجنب الخطأ بالضغط */}
      {guardConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs font-['Tajawal',sans-serif]" dir="rtl">
          <div className="bg-white rounded-3xl shadow-2xl border border-purple-100 w-full max-w-md p-5 sm:p-6 space-y-4 text-right animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs ${
                  guardConfirm.kind === 'arrive'
                    ? 'bg-sky-600'
                    : guardConfirm.kind === 'insrecv'
                    ? 'bg-amber-600'
                    : guardConfirm.kind === 'exit'
                    ? 'bg-rose-600'
                    : 'bg-emerald-600'
                }`}>
                  <AlertTriangle className="w-5 h-5 text-amber-200" />
                </div>
                <div>
                  <h3 className="font-black text-base text-slate-900">
                    تنبيه تأكيد الإرسال
                  </h3>
                  <span className="text-[11px] text-purple-700 font-bold block">
                    {guardConfirm.kind === 'arrive'
                      ? 'إجراء: وصول العميل'
                      : guardConfirm.kind === 'insrecv'
                      ? 'إجراء: استلام التأمين كاش'
                      : guardConfirm.kind === 'exit'
                      ? 'إجراء: خروج العميل'
                      : 'إجراء: إعادة التأمين كاش'}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setGuardConfirm(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Warning Note - لتجنب الخطأ بالضغط */}
            <div className="bg-amber-50 border border-amber-200/90 rounded-2xl p-3 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-950 leading-relaxed font-semibold">
                تنبيه لتجنب الخطأ بالضغط: هل أنت متأكد من رغبتك في إرسال هذا التنبيه للإدارة والموظف المسؤول؟
              </p>
            </div>

            {/* Target Booking Info Card */}
            <div className="bg-slate-50/80 rounded-2xl p-3.5 border border-slate-100 space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-700">
                <span className="text-slate-500 font-medium">اسم العميل:</span>
                <span className="font-bold text-slate-900">{guardConfirm.booking.customerName}</span>
              </div>
              <div className="flex items-center justify-between text-slate-700">
                <span className="text-slate-500 font-medium">العقار / الشاليه:</span>
                <span className="font-bold text-purple-900">{guardConfirm.booking.propertyName}</span>
              </div>
              <div className="flex items-center justify-between text-slate-700">
                <span className="text-slate-500 font-medium">رقم الجوال:</span>
                <span className="font-mono font-bold text-slate-800">{guardConfirm.booking.customerPhone}</span>
              </div>
              {(guardConfirm.kind === 'insrecv' || guardConfirm.kind === 'insret') && (
                <div className="flex items-center justify-between text-slate-700 pt-1.5 border-t border-slate-200/70">
                  <span className="text-slate-500 font-medium">مبلغ التأمين:</span>
                  <span className="font-mono font-bold text-amber-800">{guardConfirm.booking.insuranceAmount} ريال</span>
                </div>
              )}
            </div>

            {/* Explanation Message */}
            <p className="text-xs text-slate-600 leading-relaxed px-1">
              {guardConfirm.kind === 'arrive'
                ? `سيتم إرسال إشعار فوري للإدارة والموظف المسؤول بأن العميل (${guardConfirm.booking.customerName}) وصل لاستلام الاستراحة.`
                : guardConfirm.kind === 'insrecv'
                ? `سيتم إرسال إشعار فوري للإدارة والموظف المسؤول باستلامك مبلغ التأمين (${guardConfirm.booking.insuranceAmount} ريال) كاش.`
                : guardConfirm.kind === 'exit'
                ? `سيتم تسجيل خروج العميل (${guardConfirm.booking.customerName}) وإرسال إشعار للإدارة والموظف بأن العقار جاهز للمعاينة.`
                : `سيتم إرسال إشعار فوري للإدارة والموظف بتأكيد تسليم وإعادة مبلغ التأمين (${guardConfirm.booking.insuranceAmount} ريال) كاش للعميل.`}
            </p>

            {/* Action Buttons: إرسال and إلغاء */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                onClick={() => {
                  const { kind, booking: bk } = guardConfirm;
                  if (kind === 'arrive') {
                    guardMarkArrived(bk.id);
                    showToast('تم إرسال تنبيه وصول العميل للموظف والإدارة بنجاح ✓');
                  } else if (kind === 'insrecv') {
                    guardReceiveInsurance(bk.id);
                    showToast('تم إرسال تنبيه استلام التأمين كاش للموظف والإدارة بنجاح ✓');
                  } else if (kind === 'exit') {
                    markCheckedOut(bk.id);
                    guardRequestInsuranceReturn(bk.id);
                    showToast('تم إرسال تنبيه خروج العميل وجاهزية التأمين بنجاح ✓');
                  } else {
                    returnInsuranceDeposit(bk.id);
                    showToast('تم إرسال تنبيه إعادة التأمين كاش للعميل بنجاح ✓');
                  }
                  setGuardConfirm(null);
                }}
                className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-md flex items-center justify-center gap-2 btn-beam-shine transition-all"
              >
                <Send className="w-4 h-4" />
                <span>إرسال</span>
              </button>
              <button
                onClick={() => setGuardConfirm(null)}
                className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-bold rounded-xl cursor-pointer flex items-center justify-center gap-2 transition-colors border border-slate-200"
              >
                <X className="w-4 h-4" />
                <span>إلغاء</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Toast */}
      {toastMessage && (
        <div className="bg-emerald-600 text-white p-3 rounded-2xl text-xs font-bold shadow-lg flex items-center justify-between animate-in fade-in slide-in-from-top duration-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-white hover:opacity-80 cursor-pointer">
            ✕
          </button>
        </div>
      )}

      {/* Header bar */}
      <div className="bg-transparent flex items-center justify-between pt-1 px-1">
        <div className="flex items-center gap-2">
          {!isGuard && (
            <button
              onClick={() => setBookingModalOpen(true)}
              className="btn-mauve-shiny font-bold py-2.5 px-4 rounded-2xl shadow-md flex items-center gap-1.5 transition-all text-xs sm:text-sm cursor-pointer"
            >
              <Plus className="w-4 h-4 text-purple-200" />
              <span className="leading-none">حجز جديد</span>
            </button>
          )}

          <button
            onClick={() => showToast('تم تحديث البيانات الحية لكافة الاستراحات بنجاح')}
            className="w-10 h-10 rounded-2xl bg-white border border-purple-100/90 shadow-xs flex items-center justify-center text-slate-700 hover:text-purple-700 hover:bg-purple-50 transition-all cursor-pointer"
            title="تحديث البيانات"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        <div className="text-right">
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center justify-end gap-2">
            <span>{isGuard ? 'دخول وخروج اليوم' : 'لوحة التحكم المركزية'}</span>
          </h2>
          <p className="text-[11px] sm:text-xs text-slate-500 font-medium -mt-0.5">
            {isGuard
              ? 'متابعة وتأكيد وصول وخروج النزلاء واستلام وإعادة التأمين'
              : 'متابعة فورية وسريعة لكل عميل في صف واحد أفقي'}
          </p>
        </div>
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Card 1: Today Arrivals */}
        <div
          onClick={() => setActiveFilter('arrivals')}
          className={`bg-white p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
            activeFilter === 'arrivals' ? 'border-sky-500 ring-2 ring-sky-200 bg-sky-50/20' : 'border-purple-100 hover:border-purple-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-sky-700">
            <span>دخول اليوم</span>
            <span className="w-2 h-2 rounded-full bg-sky-500" />
          </div>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-black font-mono text-slate-900">{visibleArrivals.length}</span>
            <span className="text-xs text-slate-400">نزيل</span>
          </div>
        </div>

        {/* Card 2: Today Departures */}
        <div
          onClick={() => setActiveFilter('departures')}
          className={`bg-white p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
            activeFilter === 'departures' ? 'border-rose-500 ring-2 ring-rose-200 bg-rose-50/20' : 'border-purple-100 hover:border-purple-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-rose-700">
            <span>خروج اليوم</span>
            <span className="w-2 h-2 rounded-full bg-rose-500" />
          </div>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-black font-mono text-slate-900">{todayDepartures.length}</span>
            <span className="text-xs text-slate-400">نزيل</span>
          </div>
        </div>

        {/* Card 3: Awaiting Deposit */}
        <div
          onClick={() => setActiveFilter('waitingDeposit')}
          className={`bg-white p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
            activeFilter === 'waitingDeposit' ? 'border-amber-500 ring-2 ring-amber-200 bg-amber-50/20' : 'border-purple-100 hover:border-purple-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-amber-700">
            <span>بانتظار العربون</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-black font-mono text-amber-900">{waitingDepositBookings.length}</span>
            <span className="text-xs text-slate-400">معلق</span>
          </div>
        </div>

        {/* Card 4: Completed Bookings */}
        <div
          onClick={() => setActiveFilter('all')}
          className={`bg-white p-4 rounded-2xl border transition-all cursor-pointer shadow-xs ${
            activeFilter === 'all' ? 'border-purple-500 ring-2 ring-purple-200 bg-purple-50/20' : 'border-purple-100 hover:border-purple-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-purple-700">
            <span>حجوزات مكتملة</span>
            <CheckCircle2 className="w-4 h-4 text-purple-600" />
          </div>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-2xl sm:text-3xl font-black font-mono text-purple-950">{completedBookingsCount}</span>
            <span className="text-xs text-slate-400">مكتمل</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-2.5 shadow-xs border border-purple-100/90 flex flex-wrap items-center justify-between gap-2.5">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث سريع بالاسم أو رقم الجوال..."
            className="w-full pl-8 pr-9 py-2 bg-slate-50 border border-slate-200/80 rounded-xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:border-purple-600 focus:bg-white transition-all"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-thin">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeFilter === 'all'
                ? 'bg-purple-700 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            كافة الحجوزات ({activeBookings.length})
          </button>
          <button
            onClick={() => setActiveFilter('arrivals')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeFilter === 'arrivals'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            دخول اليوم ({visibleArrivals.length})
          </button>
          <button
            onClick={() => setActiveFilter('departures')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeFilter === 'departures'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            خروج اليوم ({todayDepartures.length})
          </button>
          <button
            onClick={() => setActiveFilter('waitingDeposit')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeFilter === 'waitingDeposit'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            انتظار العربون ({waitingDepositBookings.length})
          </button>
        </div>
      </div>

      {/* TODAY'S ARRIVALS SECTION (لوحة التحكم المركزية - إعادة ترتيب وتنسيق حركات دخول اليوم) */}
      {(activeFilter === 'arrivals' || activeFilter === 'all') && (
        <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-sm border border-purple-100/90 space-y-4 font-['Tajawal',sans-serif]">
          {/* Section Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-3.5 border-slate-100">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 text-xs text-sky-700 font-bold bg-sky-50 px-3 py-1 rounded-full border border-sky-200">
                <span className="w-2 h-2 rounded-full bg-sky-500 animate-pulse" />
                <span>مباشر اليوم</span>
              </div>
              <span className="text-xs text-slate-500 font-medium">
                {isGuard ? 'حركات الاستقبال والتسليم' : ''}
              </span>
            </div>

            <div className="text-right">
              <h3 className="font-black text-base sm:text-lg text-slate-900 flex items-center justify-end gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
                <span>حركات دخول اليوم ({searchFilteredArrivals.length})</span>
              </h3>
              <p className="text-[11px] text-slate-500 -mt-0.5">
              </p>
            </div>
          </div>

          {searchFilteredArrivals.length === 0 ? (
            <div className="text-center py-10 bg-slate-50/70 rounded-2xl border border-dashed border-slate-200 text-slate-400 text-xs font-medium space-y-1">
              <Calendar className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-bold text-slate-600">لا توجد حركات دخول مسجلة لليوم مطابقة لخيارات البحث</p>
              <p className="text-[11px] text-slate-400">ستظهر هنا أي حجوزات جديدة يتم تسجيل موعد دخولها اليوم تلقائياً</p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {searchFilteredArrivals.map((bk, idx) => {
                const isHamran = bk.propertyId === 'hamran' || bk.propertyName.includes('حمران');
                const isInsurancePaid = Boolean(bk.insuranceReceivedCash || bk.insurancePaymentMethod);
                const isPaidInFull = bk.remainingAmount <= 0;

                return (
                  <div
                    key={`${bk.id || 'arr'}-${idx}`}
                    className="bg-white rounded-2xl border border-slate-200/90 hover:border-purple-300 shadow-2xs hover:shadow-xs transition-all p-3 sm:p-4 space-y-2.5 font-['Tajawal',sans-serif]"
                  >
                    {/* Row 1: اسم العقار • كود الحجز • المسوقة */}
                    <div className="flex flex-wrap items-center justify-between gap-1.5 pb-2 border-b border-slate-100">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11px] text-slate-400 font-bold">اسم العقار:</span>
                        <span className="font-black text-sm text-[#2E1045] flex items-center gap-1.5">
                          <Home className="w-3.5 h-3.5 text-purple-700" />
                          <span>{bk.propertyName} {bk.sectionName ? `(${bk.sectionName})` : ''}</span>
                        </span>
                        <span className="font-mono text-[11px] text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-100 font-bold">
                          #{bk.bookingNumber}
                        </span>
                      </div>
                      {bk.marketerName && (
                        <div className="text-[11px] font-bold text-purple-900 bg-purple-50/80 px-2 py-0.5 rounded-md border border-purple-100 flex items-center gap-1">
                          <span className="text-slate-400 font-normal">المسوقة:</span>
                          <span>{bk.marketerName}</span>
                        </div>
                      )}
                    </div>

                    {/* Row 2: اسم العميل • فطور • تنسيق */}
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      {/* اسم العميل */}
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-purple-100 to-indigo-50 text-purple-700 flex items-center justify-center font-black text-xs shrink-0 border border-purple-200">
                          {bk.customerName.slice(0, 1)}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] text-slate-400 font-medium">اسم العميل:</span>
                            <span className="font-black text-slate-900 text-xs sm:text-sm truncate">
                              {bk.customerName}
                            </span>
                          </div>
                          <span className="font-mono text-[11px] text-slate-500 block -mt-0.5">
                            {bk.customerPhone}
                          </span>
                        </div>
                      </div>

                      {/* فطور وتنسيق */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {/* فطور */}
                        <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold bg-amber-50 text-amber-900 border border-amber-200 shadow-2xs">
                          <Coffee className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                          <span>
                            فطور: {bk.breakfastOption || 'فطور شامي فاخر'} {bk.breakfastPrice ? `(${bk.breakfastPrice} ر.س)` : ''}
                          </span>
                        </div>

                        {/* تنسيق */}
                        {bk.coordinatorName ? (
                          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold bg-pink-50 text-pink-900 border border-pink-200 shadow-2xs">
                            <Sparkles className="w-3.5 h-3.5 text-pink-700 shrink-0" />
                            <span>
                              تنسيق: {bk.coordinatorName} {bk.coordinatorPrice ? `(${bk.coordinatorPrice} ر.س)` : ''}
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-medium bg-slate-50 text-slate-400 border border-slate-200">
                            <span>تنسيق: لا يوجد</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Row 3: سير الحالة والأزرار السريعة + شريط منسدل ليظهر أزرار التفاعل والمراسلة */}
                    <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-1.5">
                      {/* إجراءات الحالات: انتظار الوصول / وصل العميل • دفع المتبقي / رسالة ترحيب • دفع التأمين */}
                      <div className="flex items-center gap-1.5 flex-wrap flex-1 min-w-[280px]">
                        {/* 1. انتظار الوصول / وصل العميل */}
                        <button
                          type="button"
                          onClick={() => handleGuardArrivalClick(bk)}
                          className={`py-1.5 px-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs ${
                            bk.guestArrived
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                              : 'bg-sky-600 hover:bg-sky-700 text-white border-sky-600 shadow-xs active:scale-95'
                          }`}
                          title="مسؤولية الحارس: تسجيل وصول العميل وإرسال إشعار فوري للمسوقة والإدارة"
                        >
                          <span className={`w-2 h-2 rounded-full ${bk.guestArrived ? 'bg-emerald-500' : 'bg-white'}`} />
                          <span>
                            {bk.guestArrived ? `وصل العميل ✓ ${bk.guestArrivedAt ? `(${bk.guestArrivedAt})` : ''}` : 'انتظار الوصول • [وصل العميل]'}
                          </span>
                        </button>

                        {/* 2. دفع المتبقي / رسالة ترحيب وطلب دفع */}
                        <button
                          type="button"
                          onClick={() => openMarketerPaymentModal(bk, bk.remainingAmount > 0 ? 'payment' : 'welcome')}
                          className={`py-1.5 px-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs ${
                            isPaidInFull
                              ? 'bg-purple-50 text-purple-900 border-purple-200 hover:bg-purple-100'
                              : 'bg-purple-600 hover:bg-purple-700 text-white border-purple-600 shadow-xs active:scale-95'
                          }`}
                          title="مسؤولية المسوقة: رسالة ترحيب وخيارات طلب وإكمال دفع المبلغ المتبقي"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>
                            {isPaidInFull ? 'دفع المتبقي: مسدد بالكامل ✓' : `دفع المتبقي (${bk.remainingAmount} ر.س) • رسالة ترحيب`}
                          </span>
                        </button>

                        {/* 3. دفع التأمين */}
                        <button
                          type="button"
                          onClick={() => openInsuranceModal(bk)}
                          className={`py-1.5 px-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs ${
                            isInsurancePaid
                              ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                              : 'bg-amber-600 hover:bg-amber-700 text-white border-amber-600 shadow-xs active:scale-95'
                          }`}
                          title="تحصيل وتأكيد استلام التأمين (كاش أو إيصال)"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>
                            {isInsurancePaid ? `دفع التأمين: مستلم ✓ (${bk.insurancePaymentMethod === 'cash' || bk.insuranceReceivedCash ? 'كاش' : 'إيصال'})` : `دفع التأمين (${bk.insuranceAmount} ر.س)`}
                          </span>
                        </button>
                      </div>

                      {/* 4. شريط منسدل ليظهر أزرار التفاعل والمراسلة */}
                      <button
                        type="button"
                        onClick={() => toggleBookingExpanded(bk.id)}
                        className={`py-1.5 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                          expandedBookingIds[bk.id]
                            ? 'bg-purple-700 text-white border-purple-700 shadow-xs'
                            : 'bg-slate-50 hover:bg-slate-100 text-purple-900 border-purple-200 shadow-2xs hover:border-purple-300'
                        }`}
                        title="فتح أو إغلاق شريط أزرار التفاعل والمراسلة والملخص المالي"
                      >
                        <span>شريط منسدل ليظهر أزرار التفاعل والمراسلة</span>
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${expandedBookingIds[bk.id] ? 'rotate-180' : ''}`} />
                      </button>
                    </div>

                    {/* الشريط المنسدل عند الفتح (أزرار التفاعل والمراسلة + التفاصيل المالية) */}
                    {expandedBookingIds[bk.id] && (
                      <div className="pt-2.5 border-t border-purple-100 space-y-2 animate-in fade-in slide-in-from-top-1 duration-150">
                        {/* شريط قنوات التواصل السريع المباشرة */}
                        <div className="bg-slate-50/90 border border-slate-200/70 rounded-xl p-1.5 flex items-center justify-between gap-1 text-xs">
                          <div className="grid grid-cols-4 gap-1.5 w-full">
                            {/* 1. العميل (واتساب + اتصال) */}
                            <div className="flex items-center justify-between bg-emerald-50/90 border border-emerald-200 rounded-lg p-1.5 text-[11px] font-bold text-emerald-800">
                              <a
                                href={getWhatsAppCustomerUrl(bk.customerPhone, bk.customerName, bk.propertyName)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 hover:text-emerald-950 truncate flex-1"
                                title={`محادثة واتساب مع العميل (${bk.customerName})`}
                              >
                                <MessageCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                <span className="truncate">تواصل العميل</span>
                              </a>
                              <a
                                href={`tel:${bk.customerPhone}`}
                                className="p-1 hover:bg-emerald-100 rounded text-emerald-700 shrink-0"
                                title={`اتصال هاتفي بالعميل (${bk.customerPhone})`}
                              >
                                <Phone className="w-3 h-3 text-emerald-600" />
                              </a>
                            </div>

                            {/* 2. الحارس (واتساب + اتصال) */}
                            <div className="flex items-center justify-between bg-sky-50/90 border border-sky-200 rounded-lg p-1.5 text-[11px] font-bold text-sky-800">
                              <a
                                href={getWhatsAppGuardUrl(bk)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 hover:text-sky-950 truncate flex-1"
                                title={`محادثة واتساب مع الحارس (${guard?.name || 'أبو راشد'})`}
                              >
                                <ShieldCheck className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                                <span className="truncate">تواصل الحارس</span>
                              </a>
                              <a
                                href={`tel:${guard?.phone || '0598881234'}`}
                                className="p-1 hover:bg-sky-100 rounded text-sky-700 shrink-0"
                                title={`اتصال بالحارس (${guard?.phone || '0598881234'})`}
                              >
                                <Phone className="w-3 h-3 text-sky-600" />
                              </a>
                            </div>

                            {/* 3. الإدارة (واتساب + اتصال) */}
                            <div className="flex items-center justify-between bg-purple-50/90 border border-purple-200 rounded-lg p-1.5 text-[11px] font-bold text-purple-900">
                              <a
                                href={getWhatsAppAdminUrl(bk)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 hover:text-purple-950 truncate flex-1"
                                title="محادثة واتساب مع الإدارة العامة"
                              >
                                <Building2 className="w-3.5 h-3.5 text-purple-700 shrink-0" />
                                <span className="truncate">تواصل الإدارة</span>
                              </a>
                              <a
                                href="tel:0500000001"
                                className="p-1 hover:bg-purple-100 rounded text-purple-800 shrink-0"
                                title="اتصال هاتفي بالإدارة العامة (0500000001)"
                              >
                                <Phone className="w-3 h-3 text-purple-700" />
                              </a>
                            </div>

                            {/* 4. تفاصيل الحجز */}
                            <button
                              type="button"
                              onClick={() => {
                                setDetailsTitle('تفاصيل الحجز الكاملة');
                                setSelectedBookingForDetails(bk);
                              }}
                              className="flex items-center justify-center gap-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg p-1.5 text-[11px] font-bold text-slate-700 cursor-pointer transition-colors shadow-2xs"
                              title="عرض كافة تفاصيل الحجز والعقد والخدمات"
                            >
                              <Eye className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                              <span>تفاصيل الحجز</span>
                            </button>
                          </div>
                        </div>

                        {/* شريط الملخص المالي التفصيلي */}
                        <div className="grid grid-cols-4 gap-1.5 text-center text-xs bg-slate-50/90 p-1.5 rounded-xl border border-slate-100">
                          <div className="bg-white py-1 px-1 rounded-lg border border-slate-100">
                            <span className="text-[10px] text-slate-400 block font-medium">الإجمالي</span>
                            <span className="font-mono font-bold text-slate-900 text-xs sm:text-sm">{bk.totalPrice} <span className="text-[9px] font-sans">ر.س</span></span>
                          </div>
                          <div className="bg-white py-1 px-1 rounded-lg border border-slate-100">
                            <span className="text-[10px] text-slate-400 block font-medium">العربون</span>
                            <span className="font-mono font-bold text-emerald-700 text-xs sm:text-sm">{bk.depositPaid} <span className="text-[9px] font-sans">ر.س</span></span>
                          </div>
                          <div className="bg-white py-1 px-1 rounded-lg border border-purple-100 bg-purple-50/30">
                            <span className="text-[10px] text-purple-700 block font-medium">المتبقي</span>
                            <span className={`font-mono font-black text-xs sm:text-sm ${bk.remainingAmount > 0 ? 'text-purple-900' : 'text-emerald-700'}`}>
                              {bk.remainingAmount > 0 ? `${bk.remainingAmount} ر.س` : 'مسدد ✓'}
                            </span>
                          </div>
                          <div className="bg-white py-1 px-1 rounded-lg border border-amber-100 bg-amber-50/30">
                            <span className="text-[10px] text-amber-700 block font-medium">التأمين</span>
                            <span className="font-mono font-bold text-amber-800 text-xs sm:text-sm">{bk.insuranceAmount} <span className="text-[9px] font-sans">ر.س</span></span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TODAY'S DEPARTURES SECTION (مغادرة اليوم: تذكير المسوقة بالخروج • معاينة الحارس للتأمين والأضرار • جمع الرسوم الإدارية وحساب الصافي ونسبة المسوقين 5% أو 7% بموافقة الإدارة) */}
      {(activeFilter === 'departures' || activeFilter === 'all') && (
        <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-sm border border-rose-100/90 space-y-4 font-['Tajawal',sans-serif]">
          {/* Section Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-3.5 border-slate-100">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 text-xs text-rose-700 font-bold bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                <span>مغادرة وخروج اليوم</span>
              </div>
              <span className="text-xs text-slate-500 font-medium">
                {isGuard ? 'معاينة خروج النزلاء والتأمين والأضرار' : 'تذكير الخروج • معاينة التأمين • تصفية الرسوم الإدارية والصافي وعمولة المسوقة'}
              </span>
            </div>

            <div className="text-right">
              <h3 className="font-black text-base sm:text-lg text-slate-900 flex items-center justify-end gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <span>حركات خروج ومغادرة اليوم ({searchFilteredDepartures.length})</span>
              </h3>
              <p className="text-[11px] text-slate-500 -mt-0.5">
                تذكير المسوقة بالخروج • فحص الحارس للتأمين والأضرار بالصور • تصفية الصافي والنسبة
              </p>
            </div>
          </div>

          {searchFilteredDepartures.length === 0 ? (
            <div className="text-center py-10 bg-slate-50/70 rounded-2xl border border-dashed border-slate-200 text-slate-400 text-xs font-medium space-y-1">
              <Calendar className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-bold text-slate-600">لا توجد حركات خروج مسجلة لليوم مطابقة لخيارات البحث</p>
              <p className="text-[11px] text-slate-400">ستظهر هنا أي حجوزات يحل موعد مغادرتها وخروجها اليوم تلقائياً</p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {searchFilteredDepartures.map((bk, idx) => {
                const adminFee = bk.adminFee ?? 50;
                const netRevenue = Math.max(0, bk.totalPrice - adminFee);
                const comm5 = Math.round(netRevenue * 0.05);
                const comm7 = Math.round(netRevenue * 0.07);
                const isApproved7 = Boolean(bk.adminApprovedFullBooking);
                const effectiveComm = isApproved7 ? (bk.marketerCommission || comm7) : comm5;
                const effectivePercent = isApproved7 ? 7 : 5;
                const depKey = bk.id ? `dep-${bk.id}` : `dep-${idx}`;
                const isExpanded = Boolean(expandedBookingIds[depKey]);

                return (
                  <div
                    key={depKey}
                    className="bg-white rounded-2xl border border-slate-200/90 hover:border-rose-300 shadow-2xs hover:shadow-xs transition-all p-3 sm:p-4 space-y-2.5 font-['Tajawal',sans-serif]"
                  >
                    {/* Row 1: اسم العقار • كود الحجز • المسوقة */}
                    <div className="flex flex-wrap items-center justify-between gap-1.5 pb-2 border-b border-slate-100">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11px] text-slate-400 font-bold">اسم العقار:</span>
                        <span className="font-black text-sm text-[#2E1045] flex items-center gap-1.5">
                          <Home className="w-3.5 h-3.5 text-rose-700" />
                          <span>{bk.propertyName} {bk.sectionName ? `(${bk.sectionName})` : ''}</span>
                        </span>
                        <span className="font-mono text-[11px] text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100 font-bold">
                          #{bk.bookingNumber}
                        </span>
                      </div>
                      {bk.marketerName && (
                        <div className="text-[11px] font-bold text-purple-900 bg-purple-50/80 px-2 py-0.5 rounded-md border border-purple-100 flex items-center gap-1">
                          <span className="text-slate-400 font-normal">المسوقة:</span>
                          <span>{bk.marketerName}</span>
                        </div>
                      )}
                    </div>

                    {/* Row 2: اسم العميل • فطور • تنسيق */}
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      {/* اسم العميل */}
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-rose-100 to-pink-50 text-rose-700 flex items-center justify-center font-black text-xs shrink-0 border border-rose-200 shadow-2xs">
                          {bk.customerName.slice(0, 1)}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] text-slate-400 font-medium">اسم العميل:</span>
                            <span className="font-black text-slate-900 text-xs sm:text-sm truncate">
                              {bk.customerName}
                            </span>
                          </div>
                          <span className="font-mono text-[11px] text-slate-500 block -mt-0.5">
                            {bk.customerPhone}
                          </span>
                        </div>
                      </div>

                      {/* فطور وتنسيق */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {bk.breakfastOption && (
                          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold bg-amber-50 text-amber-900 border border-amber-200 shadow-2xs">
                            <Coffee className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                            <span>فطور: {bk.breakfastOption}</span>
                          </div>
                        )}
                        {bk.coordinatorName && (
                          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold bg-pink-50 text-pink-900 border border-pink-200 shadow-2xs">
                            <Sparkles className="w-3.5 h-3.5 text-pink-700 shrink-0" />
                            <span>تنسيق: {bk.coordinatorName}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Row 3: سير الحالة والأزرار السريعة للمغادرة + شريط منسدل ليظهر أزرار التفاعل والمراسلة */}
                    <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-1.5">
                      {/* إجراءات المغادرة: معاينة وخروج الحارس • تذكير المسوقة • حالة التأمين */}
                      <div className="flex items-center gap-1.5 flex-wrap flex-1 min-w-[280px]">
                        {/* 1. الحارس: معاينة الخروج والتأمين */}
                        <button
                          type="button"
                          onClick={() => openGuardInspectionModal(bk)}
                          className={`py-1.5 px-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs ${
                            bk.checkedOut
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                              : 'bg-rose-600 hover:bg-rose-700 text-white border-rose-600 shadow-xs active:scale-95'
                          }`}
                          title="مسؤولية الحارس: فحص الشاليه والأضرار وإعادة التأمين أو خصم مبلغ"
                        >
                          <span className={`w-2 h-2 rounded-full ${bk.checkedOut ? 'bg-emerald-500' : 'bg-white'}`} />
                          <span>
                            {bk.checkedOut ? `تم الخروج ✓ ${bk.checkedOutAt ? `(${bk.checkedOutAt})` : ''}` : 'بانتظار الخروج • [معاينة وتأمين]'}
                          </span>
                        </button>

                        {/* 2. المسوقة: تذكير الخروج */}
                        <button
                          type="button"
                          onClick={() => openMarketerReminderModal(bk)}
                          className={`py-1.5 px-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs ${
                            bk.checkoutReminderSent
                              ? 'bg-purple-50 text-purple-900 border-purple-200 hover:bg-purple-100'
                              : 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600 shadow-xs active:scale-95'
                          }`}
                          title="مسؤولية المسوقة: إرسال تذكير احترافي للعميل عبر واتساب بموعد الخروج"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>
                            {bk.checkoutReminderSent ? 'تم إرسال التذكير ✓' : 'تذكير الخروج للنزيل'}
                          </span>
                        </button>

                        {/* 3. التأمين: مسترد أو خصم أضرار */}
                        <div className="inline-flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl border text-xs font-bold shadow-2xs bg-slate-50 border-slate-200 text-slate-700">
                          <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                          <span>
                            {bk.insuranceReturned
                              ? 'التأمين: مسترد بالكامل ✓'
                              : bk.insuranceDeductionAmount && bk.insuranceDeductionAmount > 0
                              ? `خصم أضرار (${bk.insuranceDeductionAmount} ر.س)`
                              : `تأمين معلق (${bk.insuranceAmount} ر.س)`}
                          </span>
                        </div>
                      </div>

                      {/* 4. شريط منسدل ليظهر أزرار التفاعل والمراسلة */}
                      <button
                        type="button"
                        onClick={() => toggleBookingExpanded(depKey)}
                        className={`py-1.5 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                          isExpanded
                            ? 'bg-rose-700 text-white border-rose-700 shadow-xs'
                            : 'bg-slate-50 hover:bg-slate-100 text-rose-900 border-rose-200 shadow-2xs hover:border-rose-300'
                        }`}
                        title="فتح أو إغلاق شريط أزرار التفاعل والمراسلة والملخص المالي للمغادرة"
                      >
                        <span>شريط منسدل ليظهر أزرار التفاعل والمراسلة</span>
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                      </button>
                    </div>

                    {/* الشريط المنسدل عند الفتح (أزرار التفاعل والمراسلة + التفاصيل المالية + تقرير الأضرار إن وجد) */}
                    {isExpanded && (
                      <div className="pt-2.5 border-t border-rose-100 space-y-2 animate-in fade-in slide-in-from-top-1 duration-150">
                        {/* Damage & Deductions Banner (في حال رصد أضرار وعبث بالاستراحة) */}
                        {bk.insuranceDeductionAmount && bk.insuranceDeductionAmount > 0 && (
                          <div className="bg-amber-50/90 border border-amber-300 rounded-xl p-2.5 space-y-1.5 text-right text-xs">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-1.5">
                                <AlertTriangle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                                <span className="font-bold text-amber-950">
                                  تقرير الحارس: خصم أضرار ({bk.insuranceDeductionAmount} ر.س)
                                </span>
                              </div>
                              <span className="font-mono font-black text-xs text-rose-700 bg-white px-2 py-0.5 rounded-lg border border-rose-200 shrink-0">
                                خصم {bk.insuranceDeductionAmount} ر.س
                              </span>
                            </div>
                            {bk.damageDescription && (
                              <p className="text-[11px] text-amber-900 leading-relaxed">
                                {bk.damageDescription}
                              </p>
                            )}
                            {/* Damage Photos Preview */}
                            {bk.damagePhotos && bk.damagePhotos.length > 0 && (
                              <div className="flex items-center gap-1.5 overflow-x-auto pt-1">
                                {bk.damagePhotos.map((photo, pIdx) => (
                                  <a
                                    key={pIdx}
                                    href={photo.dataUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="w-12 h-12 rounded-lg overflow-hidden border border-amber-300 bg-white shrink-0 cursor-pointer shadow-2xs"
                                    title="اضغط لفتح الصورة"
                                  >
                                    <img
                                      src={photo.dataUrl}
                                      alt={photo.name}
                                      className="w-full h-full object-cover"
                                    />
                                  </a>
                                ))}
                              </div>
                            )}
                          </div>
                        )}

                        {/* شريط قنوات التواصل السريع المباشرة */}
                        <div className="bg-slate-50/90 border border-slate-200/70 rounded-xl p-1.5 flex items-center justify-between gap-1 text-xs">
                          <div className="grid grid-cols-4 gap-1.5 w-full">
                            {/* 1. العميل (واتساب + اتصال) */}
                            <div className="flex items-center justify-between bg-emerald-50/90 border border-emerald-200 rounded-lg p-1.5 text-[11px] font-bold text-emerald-800">
                              <a
                                href={getWhatsAppCustomerUrl(bk.customerPhone, bk.customerName, bk.propertyName)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 hover:text-emerald-950 truncate flex-1"
                                title={`محادثة واتساب مع العميل (${bk.customerName})`}
                              >
                                <MessageCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                <span className="truncate">تواصل العميل</span>
                              </a>
                              <a
                                href={`tel:${bk.customerPhone}`}
                                className="p-1 hover:bg-emerald-100 rounded text-emerald-700 shrink-0"
                                title={`اتصال هاتفي بالعميل (${bk.customerPhone})`}
                              >
                                <Phone className="w-3 h-3 text-emerald-600" />
                              </a>
                            </div>

                            {/* 2. الحارس (واتساب + اتصال) */}
                            <div className="flex items-center justify-between bg-sky-50/90 border border-sky-200 rounded-lg p-1.5 text-[11px] font-bold text-sky-800">
                              <a
                                href={getWhatsAppGuardUrl(bk)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 hover:text-sky-950 truncate flex-1"
                                title={`محادثة واتساب مع الحارس (${guard?.name || 'أبو راشد'})`}
                              >
                                <ShieldCheck className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                                <span className="truncate">تواصل الحارس</span>
                              </a>
                              <a
                                href={`tel:${guard?.phone || '0598881234'}`}
                                className="p-1 hover:bg-sky-100 rounded text-sky-700 shrink-0"
                                title={`اتصال بالحارس (${guard?.phone || '0598881234'})`}
                              >
                                <Phone className="w-3 h-3 text-sky-600" />
                              </a>
                            </div>

                            {/* 3. الإدارة (واتساب + اتصال) */}
                            <div className="flex items-center justify-between bg-purple-50/90 border border-purple-200 rounded-lg p-1.5 text-[11px] font-bold text-purple-900">
                              <a
                                href={getWhatsAppAdminUrl(bk)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 hover:text-purple-950 truncate flex-1"
                                title="محادثة واتساب مع الإدارة العامة"
                              >
                                <Building2 className="w-3.5 h-3.5 text-purple-700 shrink-0" />
                                <span className="truncate">تواصل الإدارة</span>
                              </a>
                              <a
                                href="tel:0500000001"
                                className="p-1 hover:bg-purple-100 rounded text-purple-800 shrink-0"
                                title="اتصال هاتفي بالإدارة العامة (0500000001)"
                              >
                                <Phone className="w-3 h-3 text-purple-700" />
                              </a>
                            </div>

                            {/* 4. تفاصيل الحجز */}
                            <button
                              type="button"
                              onClick={() => {
                                setDetailsTitle('تفاصيل الحجز الكاملة والتسوية');
                                setSelectedBookingForDetails(bk);
                              }}
                              className="flex items-center justify-center gap-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg p-1.5 text-[11px] font-bold text-slate-700 cursor-pointer transition-colors shadow-2xs"
                              title="عرض كافة تفاصيل الحجز والتسوية"
                            >
                              <Eye className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                              <span>تفاصيل الحجز</span>
                            </button>
                          </div>
                        </div>

                        {/* شريط الملخص المالي التفصيلي للمغادرة */}
                        <div className="grid grid-cols-4 gap-1.5 text-center text-xs bg-slate-50/90 p-1.5 rounded-xl border border-slate-100">
                          <div className="bg-white py-1 px-1 rounded-lg border border-slate-100">
                            <span className="text-[10px] text-slate-400 block font-medium">الإجمالي</span>
                            <span className="font-mono font-bold text-slate-900 text-xs sm:text-sm">{bk.totalPrice} <span className="text-[9px] font-sans">ر.س</span></span>
                          </div>
                          <div className="bg-white py-1 px-1 rounded-lg border border-slate-100">
                            <span className="text-[10px] text-rose-600 block font-medium">الرسوم</span>
                            <span className="font-mono font-bold text-rose-700 text-xs sm:text-sm">{adminFee} <span className="text-[9px] font-sans">ر.س</span></span>
                          </div>
                          <div className="bg-white py-1 px-1 rounded-lg border border-purple-100 bg-purple-50/30">
                            <span className="text-[10px] text-purple-700 block font-medium">الصافي</span>
                            <span className="font-mono font-black text-purple-950 text-xs sm:text-sm">{netRevenue} <span className="text-[9px] font-sans">ر.س</span></span>
                          </div>
                          <div className="bg-white py-1 px-1 rounded-lg border border-emerald-100 bg-emerald-50/30">
                            <span className="text-[10px] text-emerald-700 block font-medium">العمولة ({effectivePercent}%)</span>
                            <span className="font-mono font-black text-emerald-700 text-xs sm:text-sm">{effectiveComm} <span className="text-[9px] font-sans">ر.س</span></span>
                          </div>
                        </div>

                        {/* Admin 7% Quick Action / Status */}
                        {isAdmin && (
                          <div className="flex items-center justify-between gap-1.5 bg-purple-50/60 border border-purple-200/70 rounded-xl px-2.5 py-1 text-xs">
                            <span className="text-[11px] text-purple-950 font-bold truncate">
                              {isApproved7 ? 'معتمد 7% كحجز كامل ✓' : 'نسبة 5% (يمكن الاعتماد لـ 7%)'}
                            </span>
                            <button
                              type="button"
                              onClick={() => toggleAdminCommissionApproval(bk.id)}
                              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border cursor-pointer transition-all ${
                                isApproved7
                                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                  : 'bg-white text-purple-900 border-purple-300 hover:bg-purple-100'
                              }`}
                            >
                              {isApproved7 ? 'إلغاء 7%' : 'اعتماد 7%'}
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ALL ACTIVE BOOKINGS TABLE (Hidden for Guard) */}
      {!isGuard && activeFilter === 'all' && (
        <div className="bg-white rounded-3xl p-3.5 sm:p-5 shadow-xs border border-purple-100/90 space-y-3">
          <div className="flex items-center justify-between border-b pb-2.5 border-slate-100">
            <span className="text-xs text-purple-700 font-bold bg-purple-50 px-2.5 py-1 rounded-full border border-purple-200">
              سجل الحجوزات
            </span>
            <h3 className="font-black text-sm sm:text-base text-slate-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-purple-700" />
              <span>كافة الحجوزات النشطة ({searchFilteredActive.length})</span>
            </h3>
          </div>

          <div className="overflow-x-auto scrollbar-thin rounded-2xl border border-purple-100/80 bg-white shadow-xs">
            <div className="min-w-[620px] sm:min-w-0">
              <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-slate-50 border-b border-slate-100 text-[11px] font-bold text-slate-500 text-center items-center">
                <div className="col-span-5 text-right pr-1">العميل والجوال والعقار</div>
                <div className="col-span-3 text-center">فترة الإقامة</div>
                <div className="col-span-2 text-center">الحساب المالي</div>
                <div className="col-span-2 text-center">التفاصيل</div>
              </div>

              <div className="divide-y divide-slate-100">
                {searchFilteredActive.map((bk, idx) => (
                  <div
                    key={`${bk.id || 'act'}-${idx}`}
                    className="grid grid-cols-12 gap-2 px-3 py-2.5 items-center text-xs hover:bg-slate-50/80 transition-colors"
                  >
                    <div className="col-span-5 text-right">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-xs shrink-0">
                          {bk.customerName.slice(0, 1)}
                        </div>
                        <div className="min-w-0">
                          <span className="font-bold text-slate-900 block truncate">{bk.customerName}</span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="font-mono text-[10px] text-slate-500">{bk.customerPhone}</span>
                            <span className="text-[10px] bg-purple-50 text-purple-800 px-1.5 rounded font-bold">
                              {bk.propertyName}
                            </span>
                            <a
                              href={getWhatsAppDirectUrl(bk.customerPhone, bk.customerName, bk.propertyName, 'arrival')}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="w-5 h-5 rounded-md bg-emerald-50 hover:bg-emerald-100 text-emerald-600 border border-emerald-200 flex items-center justify-center transition-colors"
                              title="فتح واتساب العميل"
                            >
                              <MessageCircle className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-span-3 text-center font-mono text-[10px] text-slate-600">
                      {bk.checkInDate} ← {bk.checkOutDate}
                    </div>

                    <div className="col-span-2 text-center">
                      <span className="font-bold text-slate-900 font-mono text-[11px] block">{bk.totalPrice} ر.س</span>
                      <span className="text-[10px] text-emerald-700 block font-mono">
                        العربون: {bk.depositPaid} ر.س
                      </span>
                    </div>

                    <div className="col-span-2 text-center">
                      <button
                        onClick={() => {
                          setDetailsTitle('تفاصيل الحجز الكاملة');
                          setSelectedBookingForDetails(bk);
                        }}
                        className="px-3 py-1 bg-purple-700 hover:bg-purple-800 text-white text-[10px] font-bold rounded-lg transition-colors cursor-pointer"
                      >
                        عرض
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Available Today Chalets Section */}
      {!isGuard && (
        <div className="bg-white rounded-3xl p-3.5 sm:p-5 shadow-xs border border-purple-100/90 space-y-3">
          <div className="flex items-center justify-between border-b pb-2.5 border-slate-100">
            <button
              onClick={() => setShowAvailableProps(!showAvailableProps)}
              className="px-3.5 py-1 bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-900 text-xs font-bold rounded-xl transition-all cursor-pointer shadow-xs"
            >
              {showAvailableProps ? 'إخفاء المتاح' : 'عرض المتاح'}
            </button>
            <h3 className="font-black text-sm sm:text-base text-slate-900 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-purple-700" />
              <span>المتاح اليوم ({availableTodayProperties.length})</span>
            </h3>
          </div>

          {showAvailableProps && (
            <div className="space-y-2 pt-1 animate-in fade-in duration-150">
              {availableTodayProperties.map((prop) => (
                <div
                  key={prop.id}
                  onClick={() => {
                    setSelectedPropertyId(prop.id);
                    setActiveTab('calendar');
                  }}
                  className="p-3 bg-emerald-50/40 hover:bg-emerald-50/80 rounded-2xl border border-emerald-200/80 transition-all flex items-center justify-between cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-purple-900 transition-colors">
                        {prop.name}
                      </h4>
                      <span className="text-[10px] text-slate-500">{prop.location}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-left font-mono">
                      <span className="font-bold text-xs sm:text-sm text-emerald-800 block">
                        {prop.basePriceWeekday} ر.س
                      </span>
                      <span className="text-[9px] text-slate-400">سعر الليلة</span>
                    </div>
                    <span className="text-xs bg-purple-700 text-white font-bold px-3 py-1.5 rounded-xl shadow-xs group-hover:bg-purple-800 transition-all">
                      حجز الآن
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Complete Payment Modal */}
      {paymentModalBooking && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setPaymentModalBooking(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-sm p-5 space-y-3.5 shadow-2xl border border-purple-100"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b pb-2.5 border-slate-100">
              <h4 className="font-bold text-sm text-purple-950">
                إكمال الدفع - {paymentModalBooking.customerName}
              </h4>
              <button
                onClick={() => setPaymentModalBooking(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-purple-50 rounded-2xl border border-purple-100 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">رقم الحجز:</span>
                <span className="font-mono font-bold">{paymentModalBooking.bookingNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">المبلغ المتبقي:</span>
                <span className="font-mono font-bold text-purple-900">
                  {paymentModalBooking.remainingAmount} ر.س
                </span>
              </div>
            </div>

            <label className="flex items-center gap-2 cursor-pointer bg-white border border-dashed border-purple-300 rounded-xl px-3 py-3 text-xs text-purple-900 font-bold hover:bg-purple-50/50 transition-colors">
              <Paperclip className="w-4 h-4 text-purple-700" />
              <span className="truncate">
                {paymentReceiptFile?.name || 'إرفاق إيصال التحويل البنكي (صورة أو PDF)'}
              </span>
              <input
                type="file"
                accept="image/*,application/pdf"
                className="hidden"
                onChange={(e) => handleReceiptFileChange(e.target.files?.[0])}
              />
            </label>

            {paymentFileError && (
              <p className="text-[10px] text-amber-700 font-bold">{paymentFileError}</p>
            )}

            <div className="flex gap-2 pt-1">
              <button
                disabled={!paymentReceiptFile}
                onClick={submitPaymentCompletion}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-xs"
              >
                حفظ وإكمال
              </button>
              <button
                onClick={() => setPaymentModalBooking(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Insurance Handover Confirm Modal */}
      {insuranceConfirmBooking && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setInsuranceConfirmBooking(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-sm p-5 space-y-3.5 shadow-2xl border border-purple-100"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-amber-800">
              <ShieldCheck className="w-5 h-5 text-amber-600" />
              <h4 className="font-bold text-sm">تأكيد تسليم التأمين</h4>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed">
              هل تؤكد تسليم مبلغ التأمين{' '}
              <strong className="font-mono text-amber-800">({insuranceConfirmBooking.insuranceAmount} ر.س)</strong> للعميل{' '}
              <strong>{insuranceConfirmBooking.customerName}</strong>؟ سيُرسل إشعار بذلك للإدارة.
            </p>

            <div className="flex gap-2 pt-1">
              <button
                onClick={confirmInsuranceHandover}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shadow-xs"
              >
                نعم، تم التسليم
              </button>
              <button
                onClick={() => setInsuranceConfirmBooking(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Booking Details Modal */}
      {selectedBookingForDetails && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setSelectedBookingForDetails(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-md p-5 shadow-2xl border border-purple-100 space-y-4 max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b pb-3 border-purple-100">
              <div>
                <h4 className="font-bold text-base text-slate-900">{detailsTitle}</h4>
                <span className="text-xs font-mono text-purple-700">{selectedBookingForDetails.bookingNumber}</span>
              </div>
              <button
                onClick={() => setSelectedBookingForDetails(null)}
                className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">اسم العميل:</span>
                <span className="font-bold text-slate-900">{selectedBookingForDetails.customerName}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">رقم الجوال:</span>
                <span className="font-mono font-bold text-slate-900">{selectedBookingForDetails.customerPhone}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">العقار:</span>
                <span className="font-bold text-purple-900">{selectedBookingForDetails.propertyName}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">فترة الإقامة:</span>
                <span className="font-semibold text-slate-800 font-mono">
                  من {selectedBookingForDetails.checkInDate} إلى {selectedBookingForDetails.checkOutDate} ({selectedBookingForDetails.nightsCount} ليالٍ)
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">المبلغ الإجمالي:</span>
                <span className="font-bold text-slate-900 font-mono text-sm">{selectedBookingForDetails.totalPrice} ر.س</span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">العربون المدفوع:</span>
                <span className="font-bold text-emerald-700 font-mono">{selectedBookingForDetails.depositPaid} ر.س</span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">المبلغ المتبقي للتحصيل:</span>
                <span className="font-bold text-purple-900 font-mono">{selectedBookingForDetails.remainingAmount} ر.س</span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">مبلغ التأمين المسترد:</span>
                <span className="font-bold text-amber-700 font-mono">
                  {selectedBookingForDetails.insuranceAmount} ر.س ({selectedBookingForDetails.insuranceReturned ? 'تم التسليم' : 'معلق'})
                </span>
              </div>

              {selectedBookingForDetails.paymentReceiptName && (
                <div className="flex justify-between items-center py-1 border-b border-slate-100">
                  <span className="text-slate-500">إيصال إكمال الدفع:</span>
                  <button
                    onClick={() => setViewReceiptBooking(selectedBookingForDetails)}
                    className="font-bold text-emerald-700 flex items-center gap-1 cursor-pointer"
                  >
                    <Paperclip className="w-3.5 h-3.5" />
                    <span>عرض الإيصال ({selectedBookingForDetails.paymentCompletedAt})</span>
                  </button>
                </div>
              )}

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">المسوق المعتمد:</span>
                <span className="font-bold text-slate-800">
                  {selectedBookingForDetails.marketerName || 'حجز مباشر'} ({selectedBookingForDetails.marketerCommission} ر.س)
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
              <button
                disabled={selectedBookingForDetails.remainingAmount <= 0}
                onClick={() => {
                  handlePaymentReminder(selectedBookingForDetails.id);
                  setSelectedBookingForDetails(null);
                }}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
              >
                <MessageCircle className="w-4 h-4" />
                <span>
                  {selectedBookingForDetails.remainingAmount <= 0 ? 'الدفع مكتمل ✓' : 'تذكير الدفع عبر واتساب'}
                </span>
              </button>

              <button
                onClick={() => setSelectedBookingForDetails(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold text-xs cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Receipt Modal */}
      {viewReceiptBooking && (
        <div
          className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4"
          onClick={() => setViewReceiptBooking(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto p-5 space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-sm text-purple-950 flex items-center gap-1.5">
                <Paperclip className="w-4 h-4" />
                <span>إيصال إكمال الدفع - {viewReceiptBooking.bookingNumber}</span>
              </h4>
              <button onClick={() => setViewReceiptBooking(null)} className="text-slate-400 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-600">
              بواسطة {viewReceiptBooking.paymentCompletedBy || 'الموظف'} · <span className="font-mono">{viewReceiptBooking.paymentCompletedAt}</span>
            </div>

            {viewReceiptBooking.paymentReceiptDataUrl?.startsWith('data:image') ? (
              <img
                src={viewReceiptBooking.paymentReceiptDataUrl}
                alt="إيصال"
                className="w-full rounded-2xl border border-slate-200"
              />
            ) : (
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-mono">
                {viewReceiptBooking.paymentReceiptName || 'ملف الإيصال المرفق'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* NEW MODAL 1: نافذة تأكيد وصول العميل (خيارين: دفع إيصال مع إرفاق، دفع كاش + إشعار للحارس والإدارة) */}
      {arrivalModalBooking && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Tajawal',sans-serif] animate-in fade-in"
          dir="rtl"
          onClick={() => setArrivalModalBooking(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-lg p-5 sm:p-6 space-y-4 shadow-2xl border border-purple-100 max-h-[92vh] overflow-y-auto text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-sky-600 text-white flex items-center justify-center shadow-xs">
                  <CheckCircle2 className="w-5 h-5 text-sky-100" />
                </div>
                <div>
                  <h4 className="font-black text-base text-slate-900">تسجيل وتأكيد وصول العميل</h4>
                  <p className="text-[11px] text-purple-700 font-bold">
                    إشعار فوري للحارس والإدارة وتحديد طريقة سداد المتبقي
                  </p>
                </div>
              </div>
              <button
                onClick={() => setArrivalModalBooking(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target Booking Info Card */}
            <div className="bg-slate-50/90 rounded-2xl p-3.5 border border-slate-100 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">اسم العميل:</span>
                <span className="font-bold text-slate-900">{arrivalModalBooking.customerName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">رقم الجوال:</span>
                <span className="font-mono font-bold text-slate-800">{arrivalModalBooking.customerPhone}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">العقار / الشاليه:</span>
                <span className="font-bold text-purple-900">{arrivalModalBooking.propertyName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">رقم الحجز:</span>
                <span className="font-mono font-bold text-purple-700">{arrivalModalBooking.bookingNumber}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700 pt-2 border-t border-slate-200/70">
                <span className="text-slate-500 font-medium">المبلغ المتبقي للتحصيل:</span>
                <span className={`font-mono font-bold text-sm ${arrivalModalBooking.remainingAmount > 0 ? 'text-amber-800' : 'text-emerald-700'}`}>
                  {arrivalModalBooking.remainingAmount > 0 ? `${arrivalModalBooking.remainingAmount} ر.س` : 'مدفوع بالكامل مسبقاً ✓'}
                </span>
              </div>
            </div>

            {/* Payment Method Selector (خيارين: دفع إيصال ويرفق الإيصال، أو دفع كاش) */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-900 block">
                اختر طريقة سداد المتبقي وتأكيد الوصول:
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                {/* Option 1: دفع إيصال */}
                <button
                  type="button"
                  onClick={() => {
                    setArrivalPayMethod('receipt');
                    setArrivalFileError(null);
                  }}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                    arrivalPayMethod === 'receipt'
                      ? 'border-purple-600 bg-purple-50/50 ring-2 ring-purple-200 text-purple-950'
                      : 'border-slate-200 hover:border-purple-200 text-slate-700 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <Paperclip className="w-4 h-4 text-purple-700" />
                      <span>دفع إيصال بنكي</span>
                    </span>
                    <span
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                        arrivalPayMethod === 'receipt'
                          ? 'border-purple-600 bg-purple-600'
                          : 'border-slate-300'
                      }`}
                    >
                      {arrivalPayMethod === 'receipt' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    حوالة بنكية ويجب إرفاق ملف الإيصال
                  </span>
                </button>

                {/* Option 2: دفع كاش */}
                <button
                  type="button"
                  onClick={() => {
                    setArrivalPayMethod('cash');
                    setArrivalFileError(null);
                  }}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                    arrivalPayMethod === 'cash'
                      ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-200 text-amber-950'
                      : 'border-slate-200 hover:border-amber-200 text-slate-700 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <Wallet className="w-4 h-4 text-amber-700" />
                      <span>دفع كاش مباشر</span>
                    </span>
                    <span
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                        arrivalPayMethod === 'cash'
                          ? 'border-amber-600 bg-amber-600'
                          : 'border-slate-300'
                      }`}
                    >
                      {arrivalPayMethod === 'cash' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    تسليم نقدي للحارس أو الاستراحة
                  </span>
                </button>
              </div>
            </div>

            {/* Receipt File Upload Field (ويرفق الإيصال) */}
            {arrivalPayMethod === 'receipt' && (
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-800 block">
                  إرفاق صورة إيصال السداد البنكي:
                  {arrivalModalBooking.remainingAmount > 0 && (
                    <span className="text-rose-600 mr-1">*</span>
                  )}
                </label>

                <label className="flex flex-col items-center justify-center p-3.5 border-2 border-dashed border-purple-200 hover:border-purple-400 bg-purple-50/30 rounded-2xl cursor-pointer transition-colors text-center">
                  <UploadCloud className="w-6 h-6 text-purple-600 mb-1" />
                  <span className="text-xs font-bold text-slate-700">
                    {arrivalReceiptFile ? arrivalReceiptFile.name : 'اضغط لاختيار صورة الإيصال (PNG, JPG, PDF)'}
                  </span>
                  <span className="text-[10px] text-slate-400 mt-0.5">الحد الأقصى للحجم 3 ميجابايت</span>
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    className="hidden"
                    onChange={(e) => handleArrivalReceiptChange(e.target.files?.[0])}
                  />
                </label>

                {arrivalReceiptFile && (
                  <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl text-xs text-emerald-800">
                    <span className="truncate max-w-[280px] font-mono">{arrivalReceiptFile.name}</span>
                    <button
                      type="button"
                      onClick={() => setArrivalReceiptFile(null)}
                      className="text-rose-600 hover:text-rose-800 font-bold text-xs"
                    >
                      إزالة
                    </button>
                  </div>
                )}

                {arrivalFileError && (
                  <p className="text-[11px] text-rose-700 font-bold bg-rose-50 p-2 rounded-xl border border-rose-200">
                    {arrivalFileError}
                  </p>
                )}
              </div>
            )}

            {arrivalPayMethod === 'cash' && (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-950 font-medium leading-relaxed">
                  سيتم تسجيل السداد كاش، وإرسال تنبيه فوري للحارس ({guard?.name || 'أبو راشد'}) والإدارة العامة لمتابعة استلام المبلغ بصندوق الاستراحة.
                </p>
              </div>
            )}

            {/* Notification Notice */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5 text-[11px] text-slate-600 flex items-center gap-2">
              <Send className="w-3.5 h-3.5 text-purple-700 shrink-0" />
              <span>
                سيُرسل إشعار وتنبيه فوري بالنظام إلى <strong>الحارس والإدارة</strong> فور النقر على التأكيد.
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={submitArrivalConfirmation}
                className="flex-1 py-3 px-4 bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>تأكيد وصول العميل وإرسال الإشعار</span>
              </button>
              <button
                type="button"
                onClick={() => setArrivalModalBooking(null)}
                className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold rounded-xl cursor-pointer transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NEW MODAL 2: نافذة عنصر التأمين (خيارين: دفع إيصال مع إرفاق إلزامي، دفع كاش + إشعار للحارس والإدارة) */}
      {insuranceModalBooking && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Tajawal',sans-serif] animate-in fade-in"
          dir="rtl"
          onClick={() => setInsuranceModalBooking(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-lg p-5 sm:p-6 space-y-4 shadow-2xl border border-purple-100 max-h-[92vh] overflow-y-auto text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-600 text-white flex items-center justify-center shadow-xs">
                  <ShieldCheck className="w-5 h-5 text-amber-100" />
                </div>
                <div>
                  <h4 className="font-black text-base text-slate-900">تحصيل واستلام مبلغ التأمين</h4>
                  <p className="text-[11px] text-amber-800 font-bold">
                    مبلغ التأمين المطلوب: {insuranceModalBooking.insuranceAmount} ر.س
                  </p>
                </div>
              </div>
              <button
                onClick={() => setInsuranceModalBooking(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target Booking Info Card */}
            <div className="bg-amber-50/60 rounded-2xl p-3.5 border border-amber-200/80 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">اسم العميل:</span>
                <span className="font-bold text-slate-900">{insuranceModalBooking.customerName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">العقار / الشاليه:</span>
                <span className="font-bold text-purple-900">{insuranceModalBooking.propertyName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">رقم الحجز:</span>
                <span className="font-mono font-bold text-purple-700">{insuranceModalBooking.bookingNumber}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700 pt-2 border-t border-amber-200">
                <span className="text-amber-900 font-bold">مبلغ التأمين المسترد:</span>
                <span className="font-mono font-black text-base text-amber-950">
                  {insuranceModalBooking.insuranceAmount} ر.س
                </span>
              </div>
            </div>

            {/* Payment Method Selector (خيارين: دفع إيصال ويجب إرفاق الإيصال، ودفع كاش) */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-900 block">
                اختر طريقة استلام التأمين:
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                {/* Option 1: دفع إيصال */}
                <button
                  type="button"
                  onClick={() => {
                    setInsurancePayMethod('receipt');
                    setInsuranceFileError(null);
                  }}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                    insurancePayMethod === 'receipt'
                      ? 'border-purple-600 bg-purple-50/50 ring-2 ring-purple-200 text-purple-950'
                      : 'border-slate-200 hover:border-purple-200 text-slate-700 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <Paperclip className="w-4 h-4 text-purple-700" />
                      <span>دفع إيصال بنكي</span>
                    </span>
                    <span
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                        insurancePayMethod === 'receipt'
                          ? 'border-purple-600 bg-purple-600'
                          : 'border-slate-300'
                      }`}
                    >
                      {insurancePayMethod === 'receipt' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                  </div>
                  <span className="text-[10px] text-rose-600 font-bold mt-1 block">
                    يجب إرفاق ملف الإيصال إجبارياً
                  </span>
                </button>

                {/* Option 2: دفع كاش */}
                <button
                  type="button"
                  onClick={() => {
                    setInsurancePayMethod('cash');
                    setInsuranceFileError(null);
                  }}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                    insurancePayMethod === 'cash'
                      ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-200 text-amber-950'
                      : 'border-slate-200 hover:border-amber-200 text-slate-700 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <Wallet className="w-4 h-4 text-amber-700" />
                      <span>دفع كاش مباشر</span>
                    </span>
                    <span
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                        insurancePayMethod === 'cash'
                          ? 'border-amber-600 bg-amber-600'
                          : 'border-slate-300'
                      }`}
                    >
                      {insurancePayMethod === 'cash' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    استلام نقدي مباشر من العميل
                  </span>
                </button>
              </div>
            </div>

            {/* Receipt File Upload Field - ويجب إرفاق الإيصال */}
            {insurancePayMethod === 'receipt' && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800">
                    ملف إيصال التأمين البنكي:
                    <span className="text-rose-600 mr-1">* (إلزامي)</span>
                  </label>
                  <span className="text-[10px] text-rose-600 font-bold">ويجب إرفاق الإيصال</span>
                </div>

                <label className="flex flex-col items-center justify-center p-3.5 border-2 border-dashed border-purple-300 hover:border-purple-500 bg-purple-50/40 rounded-2xl cursor-pointer transition-colors text-center">
                  <UploadCloud className="w-6 h-6 text-purple-600 mb-1" />
                  <span className="text-xs font-bold text-purple-900">
                    {insuranceReceiptFile ? insuranceReceiptFile.name : 'اضغط لإرفاق ملف إيصال التأمين'}
                  </span>
                  <span className="text-[10px] text-slate-500 mt-0.5">يُقبل صور وإيصالات بنكية حتى 3 ميجابايت</span>
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    className="hidden"
                    onChange={(e) => handleInsuranceReceiptChange(e.target.files?.[0])}
                  />
                </label>

                {insuranceReceiptFile && (
                  <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl text-xs text-emerald-800">
                    <span className="truncate max-w-[280px] font-mono">{insuranceReceiptFile.name}</span>
                    <button
                      type="button"
                      onClick={() => setInsuranceReceiptFile(null)}
                      className="text-rose-600 hover:text-rose-800 font-bold text-xs"
                    >
                      إزالة
                    </button>
                  </div>
                )}

                {insuranceFileError && (
                  <p className="text-[11px] text-rose-700 font-bold bg-rose-50 p-2 rounded-xl border border-rose-200">
                    {insuranceFileError}
                  </p>
                )}
              </div>
            )}

            {insurancePayMethod === 'cash' && (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-950 font-medium leading-relaxed">
                  تم استلام مبلغ التأمين نقداً ({insuranceModalBooking.insuranceAmount} ريال) وسيتم إشعار الحارس ({guard?.name || 'أبو راشد'}) والإدارة العامة فوراً وتوثيق العملية في سجل الحركات.
                </p>
              </div>
            )}

            {/* Notification Notice */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5 text-[11px] text-slate-600 flex items-center gap-2">
              <Send className="w-3.5 h-3.5 text-amber-700 shrink-0" />
              <span>
                سيُرسل إشعار وتنبيه فوري بالنظام إلى <strong>الحارس والإدارة</strong> فور النقر على التأكيد.
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={submitInsuranceConfirmation}
                className="flex-1 py-3 px-4 bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>تأكيد استلام التأمين وإشعار الحارس والإدارة</span>
              </button>
              <button
                type="button"
                onClick={() => setInsuranceModalBooking(null)}
                className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold rounded-xl cursor-pointer transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: إجراءات المسوقة (رسالة ترحيب + طلب وسداد الدفع بإيصال أو كاش مع إشعار الحارس) */}
      {marketerPaymentModalBooking && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Tajawal',sans-serif] animate-in fade-in"
          dir="rtl"
          onClick={() => setMarketerPaymentModalBooking(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-lg p-5 sm:p-6 space-y-4 shadow-2xl border border-purple-100 max-h-[92vh] overflow-y-auto text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-700 text-white flex items-center justify-center shadow-xs">
                  <Sparkles className="w-5 h-5 text-purple-100" />
                </div>
                <div>
                  <h4 className="font-black text-base text-slate-900">إجراءات المسوقة: الترحيب وإكمال الدفع</h4>
                  <p className="text-[11px] text-purple-700 font-bold">
                    {marketerPaymentModalBooking.customerName} • {marketerPaymentModalBooking.propertyName} (#{marketerPaymentModalBooking.bookingNumber})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setMarketerPaymentModalBooking(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Tabs: رسالة ترحيب | طلب وسداد الدفع */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setMarketerPaymentTab('welcome')}
                className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  marketerPaymentTab === 'welcome'
                    ? 'bg-white text-purple-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>1. رسالة ترحيب بالعميل</span>
              </button>
              <button
                type="button"
                onClick={() => setMarketerPaymentTab('payment')}
                className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  marketerPaymentTab === 'payment'
                    ? 'bg-white text-purple-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <DollarSign className="w-4 h-4 text-purple-700" />
                <span>2. طلب وسداد الدفع</span>
                {marketerPaymentModalBooking.remainingAmount > 0 && (
                  <span className="text-[10px] bg-purple-100 text-purple-900 px-1.5 py-0.2 rounded-md font-mono">
                    {marketerPaymentModalBooking.remainingAmount} ر.س
                  </span>
                )}
              </button>
            </div>

            {/* TAB 1: رسالة ترحيب بالعميل */}
            {marketerPaymentTab === 'welcome' && (
              <div className="space-y-3.5">
                <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-3 text-xs space-y-1.5 text-emerald-950">
                  <span className="font-bold block flex items-center gap-1.5">
                    <MessageCircle className="w-4 h-4 text-emerald-600" />
                    <span>رسالة ترحيبية فورية بالنزيل عند الوصول:</span>
                  </span>
                  <p className="text-[11px] text-emerald-800">
                    يمكنك تعديل نص الرسالة أدناه ثم النقر على زر الإرسال لفتح محادثة واتساب العميل مباشرة.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800 block">نص رسالة الترحيب:</label>
                  <textarea
                    rows={4}
                    value={marketerWelcomeCustomText}
                    onChange={(e) => setMarketerWelcomeCustomText(e.target.value)}
                    className="w-full p-3 text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 rounded-2xl transition-all resize-none outline-none leading-relaxed text-slate-800 font-medium"
                    placeholder="اكتب صيغة الترحيب هنا..."
                  />
                </div>

                <div className="flex flex-col gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => sendWelcomeMessageWhatsApp(marketerPaymentModalBooking, marketerWelcomeCustomText)}
                    className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-md flex items-center justify-center gap-2 transition-all"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>📱 إرسال رسالة الترحيب عبر واتساب للعميل</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMarketerPaymentTab('payment')}
                    className="w-full py-2.5 px-4 bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 text-xs font-bold rounded-xl cursor-pointer transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>المتابعة إلى خيار طلب وسداد الدفع</span>
                    <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                  </button>
                </div>
              </div>
            )}

            {/* TAB 2: طلب وسداد الدفع (خيارين: إيصال مع إرفاق، أو تسليم كاش مع إشعار الحارس) */}
            {marketerPaymentTab === 'payment' && (
              <div className="space-y-3.5">
                {/* Financial Summary */}
                <div className="bg-slate-50/90 rounded-2xl p-3 border border-slate-200/80 space-y-2 text-xs">
                  <div className="flex justify-between items-center text-slate-700">
                    <span className="text-slate-500 font-medium">العميل:</span>
                    <span className="font-bold text-slate-900">{marketerPaymentModalBooking.customerName}</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-700">
                    <span className="text-slate-500 font-medium">العقار / الشاليه:</span>
                    <span className="font-bold text-purple-900">{marketerPaymentModalBooking.propertyName}</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-700 pt-1.5 border-t border-slate-200/60">
                    <span className="text-slate-500 font-medium">المبلغ المتبقي للتحصيل:</span>
                    <span className={`font-mono font-black text-sm ${marketerPaymentModalBooking.remainingAmount > 0 ? 'text-purple-900' : 'text-emerald-700'}`}>
                      {marketerPaymentModalBooking.remainingAmount > 0 ? `${marketerPaymentModalBooking.remainingAmount} ر.س` : 'مسدد بالكامل مسبقاً ✓'}
                    </span>
                  </div>
                </div>

                {/* Option Switcher: دفع إيصال أو دفع كاش */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-900 block">
                    اختر طريقة سداد المبلغ المتبقي:
                  </label>

                  <div className="grid grid-cols-2 gap-2.5">
                    {/* Option A: دفع إيصال */}
                    <button
                      type="button"
                      onClick={() => {
                        setMarketerPayMethod('receipt');
                        setMarketerFileError(null);
                      }}
                      className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                        marketerPayMethod === 'receipt'
                          ? 'border-purple-600 bg-purple-50/50 ring-2 ring-purple-200 text-purple-950'
                          : 'border-slate-200 hover:border-purple-200 text-slate-700 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="font-bold text-xs flex items-center gap-1.5">
                          <Paperclip className="w-4 h-4 text-purple-700" />
                          <span>دفع إيصال بنكي</span>
                        </span>
                        <span
                          className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                            marketerPayMethod === 'receipt'
                              ? 'border-purple-600 bg-purple-600'
                              : 'border-slate-300'
                          }`}
                        >
                          {marketerPayMethod === 'receipt' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-500 mt-1 block">
                        حوالة بنكية مع خانة إرفاق الإيصال
                      </span>
                    </button>

                    {/* Option B: تسليم كاش */}
                    <button
                      type="button"
                      onClick={() => {
                        setMarketerPayMethod('cash');
                        setMarketerFileError(null);
                      }}
                      className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                        marketerPayMethod === 'cash'
                          ? 'border-amber-600 bg-amber-50/50 ring-2 ring-amber-200 text-amber-950'
                          : 'border-slate-200 hover:border-amber-200 text-slate-700 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="font-bold text-xs flex items-center gap-1.5">
                          <Wallet className="w-4 h-4 text-amber-700" />
                          <span>تسليم كاش للحارس</span>
                        </span>
                        <span
                          className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                            marketerPayMethod === 'cash'
                              ? 'border-amber-600 bg-amber-600'
                              : 'border-slate-300'
                          }`}
                        >
                          {marketerPayMethod === 'cash' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </span>
                      </div>
                      <span className="text-[10px] text-amber-800 font-bold mt-1 block">
                        إشعار للحارس بالتوجه واستلام المبلغ
                      </span>
                    </button>
                  </div>
                </div>

                {/* File Upload Box (عند اختيار إيصال) */}
                {marketerPayMethod === 'receipt' && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-800 block">
                      خانة إرفاق إيصال السداد البنكي:
                      {marketerPaymentModalBooking.remainingAmount > 0 && (
                        <span className="text-rose-600 mr-1">*</span>
                      )}
                    </label>

                    <label className="flex flex-col items-center justify-center p-3.5 border-2 border-dashed border-purple-200 hover:border-purple-400 bg-purple-50/30 rounded-2xl cursor-pointer transition-colors text-center">
                      <UploadCloud className="w-6 h-6 text-purple-600 mb-1" />
                      <span className="text-xs font-bold text-slate-700">
                        {marketerReceiptFile ? marketerReceiptFile.name : 'اضغط لاختيار صورة الإيصال أو المستند (PNG, JPG, PDF)'}
                      </span>
                      <span className="text-[10px] text-slate-400 mt-0.5">الحد الأقصى للحجم 3 ميجابايت</span>
                      <input
                        type="file"
                        accept="image/*,application/pdf"
                        className="hidden"
                        onChange={(e) => handleMarketerReceiptChange(e.target.files?.[0])}
                      />
                    </label>

                    {marketerReceiptFile && (
                      <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl text-xs text-emerald-800">
                        <span className="truncate max-w-[280px] font-mono">{marketerReceiptFile.name}</span>
                        <button
                          type="button"
                          onClick={() => setMarketerReceiptFile(null)}
                          className="text-rose-600 hover:text-rose-800 font-bold text-xs"
                        >
                          إزالة
                        </button>
                      </div>
                    )}

                    {marketerFileError && (
                      <p className="text-[11px] text-rose-700 font-bold bg-rose-50 p-2 rounded-xl border border-rose-200">
                        {marketerFileError}
                      </p>
                    )}
                  </div>
                )}

                {/* Cash Alert Box (عند اختيار كاش: يرسل إشعار للحارس للذهاب لاستلام المبلغ وسعر المبلغ المتبقي) */}
                {marketerPayMethod === 'cash' && (
                  <div className="bg-amber-50 border border-amber-300 rounded-2xl p-3.5 space-y-2 text-right">
                    <div className="flex items-start gap-2.5">
                      <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                      <div>
                        <h5 className="font-bold text-xs text-amber-950">
                          إشعار فوري للحارس للذهاب لاستلام المبلغ كاش:
                        </h5>
                        <p className="text-xs text-amber-900 mt-1 leading-relaxed">
                          عند النقر على الزر أدناه، سيتم إرسال إشعار فوري للحارس (<strong>{guard?.name || 'أبو راشد'}</strong>) للتوجه فوراً واستلام المبلغ المتبقي وقدره (<strong>{marketerPaymentModalBooking.remainingAmount} ر.س</strong>) كاش من العميل (<strong>{marketerPaymentModalBooking.customerName}</strong>) في ({marketerPaymentModalBooking.propertyName}).
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-amber-200 flex items-center justify-between">
                      <span className="text-[11px] text-amber-800 font-medium">سعر المبلغ المتبقي المطلوب كاش:</span>
                      <span className="font-mono font-black text-sm text-amber-950">
                        {marketerPaymentModalBooking.remainingAmount} ر.س
                      </span>
                    </div>
                  </div>
                )}

                {/* Submit & Cancel Buttons */}
                <div className="flex items-center gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={submitMarketerPayment}
                    className={`flex-1 py-3 px-4 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-md flex items-center justify-center gap-2 transition-all ${
                      marketerPayMethod === 'cash'
                        ? 'bg-amber-600 hover:bg-amber-700'
                        : 'bg-purple-600 hover:bg-purple-700'
                    }`}
                  >
                    {marketerPayMethod === 'cash' ? (
                      <>
                        <Send className="w-4 h-4" />
                        <span>إرسال إشعار للحارس للذهاب لاستلام الكاش ({marketerPaymentModalBooking.remainingAmount} ر.س)</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>تأكيد إرفاق الإيصال وإكمال الدفع</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setMarketerPaymentModalBooking(null)}
                    className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold rounded-xl cursor-pointer transition-colors"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL 4: تذكير النزيل بموعد الخروج (إجراء المسوقة) */}
      {reminderModalBooking && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Tajawal',sans-serif] animate-in fade-in"
          dir="rtl"
          onClick={() => setReminderModalBooking(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-lg p-5 sm:p-6 space-y-4 shadow-2xl border border-rose-100 max-h-[92vh] overflow-y-auto text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                  <MessageCircle className="w-5 h-5 text-emerald-100" />
                </div>
                <div>
                  <h4 className="font-black text-base text-slate-900">رسالة تذكير بالخروج للنزيل</h4>
                  <p className="text-[11px] text-emerald-800 font-bold">
                    إجراء المسوقة • {reminderModalBooking.customerName} (#{reminderModalBooking.bookingNumber})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setReminderModalBooking(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target Booking Info */}
            <div className="bg-emerald-50/60 rounded-2xl p-3 border border-emerald-200/80 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">النزيل:</span>
                <span className="font-bold text-slate-900">{reminderModalBooking.customerName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">العقار / الشاليه:</span>
                <span className="font-bold text-purple-900">{reminderModalBooking.propertyName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">مبلغ التأمين المسترد:</span>
                <span className="font-mono font-bold text-emerald-800">{reminderModalBooking.insuranceAmount} ر.س</span>
              </div>
            </div>

            {/* Message Textarea */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800 block">نص رسالة التذكير عبر واتساب:</label>
              <textarea
                rows={5}
                value={customReminderMsg}
                onChange={(e) => setCustomReminderMsg(e.target.value)}
                className="w-full p-3 text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-2xl transition-all resize-none outline-none leading-relaxed text-slate-800 font-medium"
              />
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => sendMarketerReminder(reminderModalBooking, customReminderMsg)}
                className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>📱 إرسال تذكير الخروج عبر واتساب العميل</span>
              </button>
              <button
                type="button"
                onClick={() => setReminderModalBooking(null)}
                className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold rounded-xl cursor-pointer transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: معاينة الحارس عند الخروج تماماً وتصفية التأمين أو خصم الأضرار مع خانة إرفاق صور */}
      {guardInspectionBooking && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-['Tajawal',sans-serif] animate-in fade-in"
          dir="rtl"
          onClick={() => setGuardInspectionBooking(null)}
        >
          <div
            className="bg-white rounded-3xl w-full max-w-lg p-5 sm:p-6 space-y-4 shadow-2xl border border-rose-100 max-h-[92vh] overflow-y-auto text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-xs">
                  <ShieldCheck className="w-5 h-5 text-rose-100" />
                </div>
                <div>
                  <h4 className="font-black text-base text-slate-900">معاينة الحارس عند خروج النزيل تماماً</h4>
                  <p className="text-[11px] text-rose-800 font-bold">
                    إشعار فوري للمسوقة والإدارة بإعادة التأمين أو خصم مبلغ الأضرار
                  </p>
                </div>
              </div>
              <button
                onClick={() => setGuardInspectionBooking(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target Booking Info Card */}
            <div className="bg-slate-50/90 rounded-2xl p-3 border border-slate-200/80 space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">النزيل:</span>
                <span className="font-bold text-slate-900">{guardInspectionBooking.customerName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">العقار / الشاليه:</span>
                <span className="font-bold text-purple-900">{guardInspectionBooking.propertyName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span className="text-slate-500 font-medium">المسوقة المسؤولة:</span>
                <span className="font-bold text-purple-900">{guardInspectionBooking.marketerName || 'حجز مباشر'}</span>
              </div>
              <div className="flex justify-between items-center text-slate-700 pt-1.5 border-t border-slate-200/70">
                <span className="text-slate-600 font-bold">إجمالي مبلغ التأمين المودع:</span>
                <span className="font-mono font-black text-sm text-amber-800">
                  {guardInspectionBooking.insuranceAmount} ر.س
                </span>
              </div>
            </div>

            {/* Choice: إعادة التأمين كاملاً أو خصم أضرار */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-900 block">
                نتيجة معاينة الاستراحة وحالة التأمين:
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                {/* Option 1: إعادة التأمين بالكامل */}
                <button
                  type="button"
                  onClick={() => {
                    setGuardInspectionResult('full_refund');
                    setGuardInspectionError(null);
                  }}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                    guardInspectionResult === 'full_refund'
                      ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-200 text-emerald-950'
                      : 'border-slate-200 hover:border-emerald-200 text-slate-700 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>إعادة التأمين كاملاً</span>
                    </span>
                    <span
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                        guardInspectionResult === 'full_refund'
                          ? 'border-emerald-600 bg-emerald-600'
                          : 'border-slate-300'
                      }`}
                    >
                      {guardInspectionResult === 'full_refund' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    الاستراحة سليمة وبدون أي تلفيات ({guardInspectionBooking.insuranceAmount} ر.س)
                  </span>
                </button>

                {/* Option 2: خصم مبلغ للعبث والأضرار */}
                <button
                  type="button"
                  onClick={() => {
                    setGuardInspectionResult('deduction');
                    setGuardInspectionError(null);
                  }}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                    guardInspectionResult === 'deduction'
                      ? 'border-rose-600 bg-rose-50/50 ring-2 ring-rose-200 text-rose-950'
                      : 'border-slate-200 hover:border-rose-200 text-slate-700 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-bold text-xs flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      <span>خصم مبلغ (أضرار وعبث)</span>
                    </span>
                    <span
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                        guardInspectionResult === 'deduction'
                          ? 'border-rose-600 bg-rose-600'
                          : 'border-slate-300'
                      }`}
                    >
                      {guardInspectionResult === 'deduction' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                  </div>
                  <span className="text-[10px] text-rose-700 font-bold mt-1 block">
                    وجود عبث أو أضرار مع إرفاق صور
                  </span>
                </button>
              </div>
            </div>

            {/* Deduction Form & Photo Upload (إذا اختار خصم مبلغ للعبث والأضرار) */}
            {guardInspectionResult === 'deduction' && (
              <div className="bg-rose-50/60 border border-rose-200 rounded-2xl p-3.5 space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-800 block">
                    المبلغ المخصوم من التأمين (ر.س): <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={guardInspectionBooking.insuranceAmount}
                    value={guardDeductionAmount || ''}
                    onChange={(e) => setGuardDeductionAmount(Number(e.target.value))}
                    placeholder={`مثال: 150 (الحد الأقصى ${guardInspectionBooking.insuranceAmount} ر.س)`}
                    className="w-full p-2.5 text-xs bg-white border border-rose-300 focus:ring-2 focus:ring-rose-200 rounded-xl outline-none font-mono font-bold text-slate-900"
                  />
                  <span className="text-[10px] text-slate-500 block">
                    المتبقي المسترد للعميل: {Math.max(0, guardInspectionBooking.insuranceAmount - (guardDeductionAmount || 0))} ر.س
                  </span>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-800 block">
                    وصف الأضرار أو العبث بالاستراحة: <span className="text-rose-600">*</span>
                  </label>
                  <textarea
                    rows={2}
                    value={guardDamageDesc}
                    onChange={(e) => setGuardDamageDesc(e.target.value)}
                    placeholder="اكتب وصف التلفيات أو العبث (مثال: كسر طاولة، تلف في مسند الكنب، اتساخ شديد في المسبح...)"
                    className="w-full p-2.5 text-xs bg-white border border-rose-300 focus:ring-2 focus:ring-rose-200 rounded-xl outline-none resize-none text-slate-800"
                  />
                </div>

                {/* خانة إرفاق صور العبث والأضرار */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800 flex items-center gap-1">
                      <Camera className="w-4 h-4 text-rose-600" />
                      <span>خانة إرفاق صور الأضرار والعبث:</span>
                    </label>
                    <span className="text-[10px] text-rose-700 font-bold">توثيق بالصور للمسوقة والإدارة</span>
                  </div>

                  <label className="flex flex-col items-center justify-center p-3.5 border-2 border-dashed border-rose-300 hover:border-rose-500 bg-white rounded-2xl cursor-pointer transition-colors text-center">
                    <UploadCloud className="w-6 h-6 text-rose-600 mb-1" />
                    <span className="text-xs font-bold text-slate-700">
                      اضغط لاختيار وإرفاق صور الأضرار (كاميرا الجوال أو الألبوم)
                    </span>
                    <span className="text-[10px] text-slate-400 mt-0.5">يمكنك اختيار عدة صور (PNG, JPG)</span>
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleDamagePhotoUpload(e.target.files)}
                    />
                  </label>

                  {/* Uploaded photos preview grid */}
                  {guardDamagePhotos.length > 0 && (
                    <div className="grid grid-cols-3 gap-2 pt-1">
                      {guardDamagePhotos.map((photo, idx) => (
                        <div key={idx} className="relative rounded-xl overflow-hidden border border-rose-200 bg-white group">
                          <img src={photo.dataUrl} alt={photo.name} className="w-full h-20 object-cover" />
                          <button
                            type="button"
                            onClick={() => removeDamagePhoto(idx)}
                            className="absolute top-1 left-1 bg-rose-600 text-white rounded-full p-1 opacity-90 hover:opacity-100 transition-opacity"
                            title="حذف الصورة"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                          <span className="text-[9px] text-slate-600 truncate block px-1 py-0.5 font-mono text-center">
                            {photo.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {guardInspectionError && (
              <p className="text-[11px] text-rose-700 font-bold bg-rose-50 p-2.5 rounded-xl border border-rose-200">
                {guardInspectionError}
              </p>
            )}

            {/* Notification Notice */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5 text-[11px] text-slate-600 flex items-center gap-2">
              <Send className="w-3.5 h-3.5 text-purple-700 shrink-0" />
              <span>
                سيُرسل إشعار وتنبيه فوري بالنظام إلى <strong>المسوقة ({guardInspectionBooking.marketerName || 'المسؤولة'}) والإدارة</strong> فور النقر على التأكيد.
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={submitGuardDepartureInspection}
                className={`flex-1 py-3 px-4 text-white text-xs sm:text-sm font-bold rounded-xl cursor-pointer shadow-md flex items-center justify-center gap-2 transition-all ${
                  guardInspectionResult === 'deduction'
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-emerald-600 hover:bg-emerald-700'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {guardInspectionResult === 'deduction'
                    ? `تأكيد الخروج وخصم (${guardDeductionAmount} ر.س) وإشعار المسوقة والإدارة`
                    : 'تأكيد الخروج وإعادة التأمين كاملاً وإشعار المسوقة والإدارة'}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setGuardInspectionBooking(null)}
                className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold rounded-xl cursor-pointer transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
